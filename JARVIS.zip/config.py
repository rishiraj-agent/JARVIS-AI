from __future__ import annotations

import os
import sys
from pathlib import Path


APP_NAME = "JARVIS"
APP_DIR = Path(os.environ.get("LOCALAPPDATA", Path.home())) / APP_NAME
DB_PATH = APP_DIR / "jarvis.sqlite3"
LOG_PATH = APP_DIR / "jarvis.log"
DEFAULT_BASE_URL = "https://api.openai.com/v1"
DEFAULT_MODEL = "gpt-4o-mini"
KEYRING_SERVICE = "JARVIS AI"
KEYRING_USERNAME = "openai-compatible-api-key"

SYSTEM_PROMPT = (
    "You are JARVIS, a calm, capable personal desktop assistant. Be concise by "
    "default, professional, friendly, and clear. Respond in the language the user "
    "uses, including Hindi and Hinglish. Ask a focused follow-up when essential "
    "information is missing. Never claim to have performed a computer action, "
    "searched live sources, or verified current information unless the application "
    "has actually done so. You cannot run shell commands or control the computer; "
    "explain that limitation honestly."
)

RESOURCE_DIR = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
ICON_PATH = RESOURCE_DIR / "assets" / "jarvis.ico"
REFERENCE_IMAGE_PATH = RESOURCE_DIR / "assets" / "ui_gui_images" / "reference_ui.png"


def ensure_app_dir() -> None:
    APP_DIR.mkdir(parents=True, exist_ok=True)
