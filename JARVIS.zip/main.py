from __future__ import annotations

import logging
import math
import os
import queue
import re
import sqlite3
import shutil
import sys
import subprocess
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from datetime import datetime
from pathlib import Path

try:
    import keyring
except ImportError:
    keyring = None

from config import (
    APP_DIR,
    DEFAULT_BASE_URL,
    DEFAULT_MODEL,
    ICON_PATH,
    REFERENCE_IMAGE_PATH,
    KEYRING_SERVICE,
    KEYRING_USERNAME,
    LOG_PATH,
    SYSTEM_PROMPT,
    ensure_app_dir,
)
from jarvis.ai_client import AIClient, AIError, AISettings
from jarvis.automation import run_command
from jarvis.storage import Storage
from jarvis.voice_input import VoiceInput
from jarvis.voice_output import VoiceOutput
from jarvis.notes_service import NotesService, ReminderService
from jarvis.system_monitor import SystemSnapshot, collect_system_snapshot
from jarvis.web_search import open_search
from jarvis.image_loader import ImageLoader


BG = "#07111d"
PANEL = "#0d1b2a"
PANEL_LIGHT = "#12273a"
CYAN = "#36d9ef"
BLUE = "#4a86ff"
TEXT = "#e7f2fb"
MUTED = "#91a6b8"
GREEN = "#62e6b0"
RED = "#ff7585"
_INSTANCE_MUTEX = None
KEYRING_ERROR = keyring.errors.KeyringError if keyring is not None else RuntimeError


class JarvisApp:
    def __init__(self, root: tk.Tk) -> None:
        ensure_app_dir()
        logging.basicConfig(
            filename=LOG_PATH,
            level=logging.WARNING,
            format="%(asctime)s %(levelname)s %(message)s",
            encoding="utf-8",
        )
        self.root = root
        self.root.title("JARVIS | Personal AI")
        self.root.geometry("1020x740")
        self.root.minsize(820, 620)
        self.root.configure(bg=BG)
        if ICON_PATH.is_file():
            try:
                self.root.iconbitmap(str(ICON_PATH))
            except tk.TclError:
                logging.warning("The JARVIS application icon could not be loaded.")
        self.storage = Storage(APP_DIR / "jarvis.sqlite3")
        self.image_loader = ImageLoader()
        self.reference_image = self.image_loader.load(REFERENCE_IMAGE_PATH, 860, 740)
        self.notes_service = NotesService(self.storage)
        self.reminder_service = ReminderService(self.storage)
        self.events: queue.Queue[tuple[str, object]] = queue.Queue()
        self.voice_output = VoiceOutput(on_done=lambda: self.events.put(("spoken", None)))
        self.voice_input = VoiceInput()
        self.messages: list[dict[str, str]] = []
        self.listening = False
        self.listen_cancel: threading.Event | None = None
        self.busy = False
        self.speaking = False
        self.animation_phase = 0
        self.current_page = ""
        self.system_snapshot: SystemSnapshot | None = None
        self.system_refresh_pending = False
        self.search_results: list[str] = []
        self.settings = self.storage.get_settings()
        self.animation_enabled = bool(self.settings.get("animations", True))
        self.typing_visible = False
        self.stream_in_progress = False
        self._build_style()
        self._build_ui()
        self._load_history()
        self._update_voice_status()
        self._animate()
        self._poll_events()
        self.root.protocol("WM_DELETE_WINDOW", self._close)

    def _build_style(self) -> None:
        style = ttk.Style(self.root)
        style.theme_use("clam")
        style.configure(
            "Jarvis.TEntry", fieldbackground=PANEL_LIGHT, foreground=TEXT,
            insertcolor=TEXT, bordercolor="#27435b", lightcolor="#27435b",
            darkcolor="#27435b", padding=8,
        )
        style.configure(
            "Jarvis.TCheckbutton", background=PANEL, foreground=TEXT,
            focuscolor=PANEL, indicatorcolor=PANEL_LIGHT,
        )
        style.map(
            "Jarvis.TCheckbutton", background=[("active", PANEL)],
            foreground=[("active", CYAN)],
        )

    def _build_ui(self) -> None:
        header = tk.Frame(self.root, bg=BG)
        header.pack(fill="x", padx=18, pady=(12, 8))
        brand = tk.Frame(header, bg=BG)
        brand.pack(side="left")
        tk.Label(brand, text="◈", fg=CYAN, bg=BG, font=("Segoe UI", 26, "bold")).pack(side="left", padx=(0, 10))
        tk.Label(brand, text="JARVIS AI", fg=TEXT, bg=BG, font=("Segoe UI", 19, "bold")).pack(side="left")
        tk.Label(brand, text="  THINK  •  ASSIST  •  AUTOMATE", fg=MUTED, bg=BG, font=("Segoe UI", 8)).pack(side="left", pady=(8, 0))
        self.header_status = tk.Label(header, text="● READY · API NOT TESTED", fg=MUTED, bg=BG, font=("Segoe UI", 9, "bold"))
        self.header_status.pack(side="left", padx=24)
        controls = tk.Frame(header, bg=BG)
        controls.pack(side="right")
        self._button(controls, "Help", self._show_help, compact=True).pack(side="left", padx=3)
        self._button(controls, "About", self._show_about, compact=True).pack(side="left", padx=3)
        self._button(controls, "⛶", self._toggle_fullscreen, compact=True).pack(side="left", padx=3)
        self._button(controls, "—", self.root.iconify, compact=True).pack(side="left", padx=3)
        self._button(controls, "□", self._toggle_maximize, compact=True).pack(side="left", padx=3)
        self._button(controls, "×", self._close, compact=True, danger=True).pack(side="left", padx=3)

        shell = tk.Frame(self.root, bg=BG)
        shell.pack(fill="both", expand=True, padx=12, pady=(0, 8))
        self.sidebar = tk.Frame(shell, bg=PANEL, width=158)
        self.sidebar.pack(side="left", fill="y", padx=(0, 8))
        self.sidebar.pack_propagate(False)
        tk.Label(self.sidebar, text="WORKSPACE", fg=MUTED, bg=PANEL, font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=12, pady=(14, 8))
        nav_items = (
            ("Home", "Home"),
            ("AI Chat", "AI Chat"),
            ("Voice Control", "Voice Control"),
            ("Applications", "Applications"),
            ("Web & Search", "Web Search"),
            ("Notes & Reminders", "Notes"),
            ("System Information", "System Info"),
            ("Automation", "Automation"),
            ("Settings", "Settings"),
        )
        self.nav_buttons: dict[str, tk.Button] = {}
        for label, page in nav_items:
            button = tk.Button(
                self.sidebar, text=f"  ◇  {label}", anchor="w",
                command=lambda selected=page: self._show_page(selected),
                bg=PANEL, fg=TEXT, activebackground=PANEL_LIGHT, activeforeground=CYAN,
                relief="flat", bd=0, padx=8, pady=8, cursor="hand2",
                font=("Segoe UI", 9),
            )
            button.pack(fill="x", padx=6, pady=1)
            self.nav_buttons[page] = button
        self.center = tk.Frame(shell, bg=BG)
        self.center.pack(side="left", fill="both", expand=True)
        self.pages: dict[str, tk.Frame] = {}
        self._build_home_page()
        self._build_chat_page()
        self._build_notes_page()
        self._build_search_page()
        self._build_apps_page()
        self._build_system_page()
        self._build_automation_page()

        self.dashboard = tk.Frame(shell, bg=PANEL, width=208)
        self.dashboard.pack(side="right", fill="y", padx=(8, 0))
        self.dashboard.pack_propagate(False)
        self._build_dashboard()
        self.dashboard_api.configure(
            text="Configured · not tested" if self._get_api_key() else "Not configured"
        )

        composer = tk.Frame(self.root, bg=PANEL, highlightbackground="#18364b", highlightthickness=1)
        composer.pack(fill="x", padx=12, pady=(0, 8))
        self.input = ttk.Entry(composer, style="Jarvis.TEntry", font=("Segoe UI", 10))
        self.input.pack(side="left", fill="x", expand=True, padx=8, pady=6, ipady=3)
        self.input.bind("<Return>", lambda _event: self._send())
        self.mic_button = self._button(composer, "🎙 Start Listening", self._toggle_listening)
        self.mic_button.pack(side="left", padx=4, pady=5)
        self.send_button = self._button(composer, "Send", self._send, primary=True)
        self.send_button.pack(side="left", padx=4, pady=5)
        self.stop_button = self._button(composer, "Stop Speaking", self._stop_speaking)
        self.stop_button.pack(side="left", padx=4, pady=5)
        self._button(composer, "Clear Chat", self._clear_chat, compact=True).pack(side="left", padx=4, pady=5)

        footer = tk.Frame(self.root, bg=BG)
        footer.pack(fill="x", padx=16, pady=(0, 6))
        self.ai_status = tk.Label(footer, text="● AI not tested", fg=MUTED, bg=BG, font=("Segoe UI", 8))
        self.ai_status.pack(side="left")
        self.mic_status = tk.Label(footer, text="● Mic idle", fg=MUTED, bg=BG, font=("Segoe UI", 8))
        self.mic_status.pack(side="left", padx=14)
        self.tts_status = tk.Label(footer, text="● Speech engine starting", fg=MUTED, bg=BG, font=("Segoe UI", 8))
        self.tts_status.pack(side="left")
        tk.Label(footer, text="Microphone is active only after you start listening", fg=MUTED, bg=BG, font=("Segoe UI", 8)).pack(side="right")

        self._show_page(str(self.settings.get("startup_page", "AI Chat")))
        self.root.bind("<F11>", lambda _event: self._toggle_fullscreen())
        self.root.bind("<Escape>", lambda _event: self.root.attributes("-fullscreen", False))
        self.root.bind_all("<Control-l>", lambda _event: self.input.focus_set())
        self.root.bind_all("<Control-n>", lambda _event: self._new_note())
        self.root.bind_all("<Control-Shift-c>", lambda _event: self._clear_chat())
        self._refresh_notes()
        self._refresh_reminders()
        self._refresh_searches()
        self._refresh_shortcuts()
        self._refresh_system()
        self._refresh_dashboard()

    def _build_home_page(self) -> None:
        page = self._new_page("Home", "JARVIS AI CONTROL CENTER")
        tk.Label(
            page,
            text="Your desktop assistant is ready. Configure cloud AI in Settings, or use local tools from the navigation.",
            fg=MUTED, bg=BG, wraplength=590, justify="left",
        ).pack(anchor="w", pady=(0, 14))
        self.home_core = tk.Canvas(page, height=235, bg=BG, highlightthickness=0)
        self.home_core.pack(fill="x", pady=8)
        quick = tk.Frame(page, bg=BG)
        quick.pack(fill="x", pady=8)
        for title, action in (
            ("Start a chat", lambda: self._show_page("AI Chat")),
            ("Create a note", self._new_note),
            ("Search the web", lambda: self._show_page("Web Search")),
            ("System dashboard", lambda: self._show_page("System Info")),
        ):
            card = tk.Frame(quick, bg=PANEL, highlightbackground="#1b435a", highlightthickness=1)
            card.pack(side="left", fill="both", expand=True, padx=4)
            self._button(card, title, action, primary=True).pack(fill="x", padx=8, pady=12)
        summary = tk.Frame(page, bg=PANEL)
        summary.pack(fill="both", expand=True, pady=(8, 0))
        self.home_summary = tk.Label(
            summary, text="Loading recent activity…", fg=MUTED, bg=PANEL,
            justify="left", anchor="nw", font=("Segoe UI", 9),
        )
        self.home_summary.pack(fill="both", expand=True, padx=14, pady=12)

    def _build_chat_page(self) -> None:
        page = tk.Frame(self.center, bg=BG)
        self.pages["AI Chat"] = page
        self.pages["Voice Control"] = page
        visual = tk.Frame(page, bg=BG)
        visual.pack(fill="x")
        self.canvas = tk.Canvas(visual, height=130, bg=BG, highlightthickness=0)
        self.canvas.pack(fill="x")
        self.state_label = tk.Label(visual, text="SYSTEM READY", fg=CYAN, bg=BG, font=("Segoe UI", 9, "bold"))
        self.state_label.pack()
        chat_frame = tk.Frame(page, bg=BG)
        chat_frame.pack(fill="both", expand=True, pady=(6, 0))
        self.chat = tk.Text(
            chat_frame, wrap="word", state="disabled", bg=PANEL, fg=TEXT,
            relief="flat", padx=18, pady=14, font=("Segoe UI", 10),
            spacing1=4, spacing3=8, selectbackground="#22536a",
        )
        scrollbar = ttk.Scrollbar(chat_frame, orient="vertical", command=self.chat.yview)
        self.chat.configure(yscrollcommand=scrollbar.set)
        self.chat.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.chat.tag_configure("user", foreground=CYAN, font=("Segoe UI", 10, "bold"))
        self.chat.tag_configure("assistant", foreground=GREEN, font=("Segoe UI", 10, "bold"))
        self.chat.tag_configure("body", foreground=TEXT)
        self.chat.tag_configure("system", foreground=MUTED, font=("Segoe UI", 9, "italic"))
        self.chat.tag_configure("timestamp", foreground=MUTED, font=("Segoe UI", 8))
        self._append_message(
            "JARVIS",
            "JARVIS AI READY\nConfigure an AI provider in Settings to begin, or try a local command such as “what time is it?”",
            "assistant",
            persist=False,
        )

    def _build_dashboard(self) -> None:
        tk.Label(self.dashboard, text="LIVE DASHBOARD", fg=CYAN, bg=PANEL, font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=12, pady=(14, 10))
        self.dashboard_api = self._dashboard_card("API CONNECTION", "Not tested")
        self.dashboard_mic = self._dashboard_card("MICROPHONE", "Idle · not recording")
        self.dashboard_tts = self._dashboard_card("SPEECH ENGINE", "Initializing…")
        self.dashboard_cpu = self._dashboard_card("CPU", "Reading…")
        self.dashboard_memory = self._dashboard_card("MEMORY", "Reading…")
        self.dashboard_disk = self._dashboard_card("DISK", "Reading…")
        self.dashboard_battery = self._dashboard_card("BATTERY", "Checking…")
        self._section_label(self.dashboard, "QUICK ACTIONS")
        quick_actions = tk.Frame(self.dashboard, bg=PANEL)
        quick_actions.pack(fill="x", padx=8)
        for index, (label, callback) in enumerate((
            ("Notepad", lambda: self._launch_app("notepad")),
            ("Calculator", lambda: self._launch_app("calculator")),
            ("Paint", lambda: self._launch_app("paint")),
            ("Browser", lambda: self._launch_app("browser")),
            ("Web Search", lambda: self._show_page("Web Search")),
            ("Create Note", self._new_note),
            ("Open Folder", self._open_folder),
            ("More Tools", lambda: self._show_page("Automation")),
        )):
            self._button(
                quick_actions, label, callback, compact=True
            ).grid(row=index // 2, column=index % 2, sticky="ew", padx=2, pady=2)
        quick_actions.grid_columnconfigure(0, weight=1)
        quick_actions.grid_columnconfigure(1, weight=1)
        self._section_label(self.dashboard, "UPCOMING")
        self.reminder_summary = tk.Label(
            self.dashboard, text="No upcoming reminders", fg=MUTED, bg=PANEL,
            wraplength=176, justify="left", font=("Segoe UI", 8),
        )
        self.reminder_summary.pack(fill="x", padx=12, pady=(0, 10))

    def _dashboard_card(self, title: str, initial: str) -> tk.Label:
        frame = tk.Frame(self.dashboard, bg=PANEL_LIGHT, highlightbackground="#1d3c51", highlightthickness=1)
        frame.pack(fill="x", padx=9, pady=3)
        tk.Label(frame, text=title, fg=MUTED, bg=PANEL_LIGHT, font=("Segoe UI", 7, "bold")).pack(anchor="w", padx=8, pady=(5, 0))
        value = tk.Label(frame, text=initial, fg=TEXT, bg=PANEL_LIGHT, font=("Segoe UI", 8), wraplength=174, justify="left")
        value.pack(anchor="w", padx=8, pady=(1, 5))
        return value

    def _section_label(self, parent: tk.Widget, text: str) -> None:
        tk.Label(parent, text=text, fg=MUTED, bg=PANEL, font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=12, pady=(10, 4))

    def _show_page(self, name: str) -> None:
        if name == "Settings":
            self._open_settings()
            return
        page = self.pages.get(name)
        if page is None:
            return
        for candidate in set(self.pages.values()):
            candidate.pack_forget()
        page.pack(fill="both", expand=True)
        self.current_page = name
        for page_name, button in self.nav_buttons.items():
            active = page_name == name or (name == "Voice Control" and page_name == "AI Chat")
            button.configure(bg=PANEL_LIGHT if active else PANEL, fg=CYAN if active else TEXT)
        if name == "System Info":
            self._refresh_system()
        elif name == "Notes":
            self._refresh_notes()
            self._refresh_reminders()
        elif name == "Applications":
            self._refresh_shortcuts()
        elif name == "Web Search":
            self._refresh_searches()

    def _toggle_maximize(self) -> None:
        try:
            is_zoomed = self.root.state() == "zoomed"
            self.root.state("normal" if is_zoomed else "zoomed")
        except tk.TclError:
            logging.warning("The window manager does not support maximize/restore.")

    def _refresh_home_summary(self) -> None:
        if not hasattr(self, "home_summary"):
            return
        try:
            notes = self.storage.get_notes()[:3]
            reminders = self.reminder_service.upcoming()[:3]
            timestamps = self.storage.message_timestamps(limit=1)
            last_chat = datetime.fromisoformat(timestamps[-1]).strftime("%b %d, %H:%M") if timestamps else "No saved conversations"
            note_lines = [f"  • {item['title']}" for item in notes] or ["  • No notes yet"]
            reminder_lines = [
                f"  • {item['due_at']} — {item['title']}" for item in reminders
            ] or ["  • No upcoming reminders"]
            lines = [
                "RECENT ACTIVITY",
                f"Last conversation: {last_chat}",
                "Recent notes:",
                *note_lines,
                "Upcoming reminders:",
                *reminder_lines,
            ]
            self.home_summary.configure(text="\n".join(lines))
        except (sqlite3.Error, ValueError):
            logging.exception("Could not load home activity summary")
            self.home_summary.configure(text="Recent activity is currently unavailable.")

    def _show_reference_image(self) -> None:
        dialog = tk.Toplevel(self.root)
        dialog.title("JARVIS interface reference")
        dialog.configure(bg=BG)
        dialog.transient(self.root)
        dialog.geometry("900x820")
        if self.reference_image is None:
            tk.Label(
                dialog,
                text="The optional reference image is unavailable.\n"
                     "Place reference_ui.png in assets/ui_gui_images.",
                fg=MUTED, bg=BG, justify="center", font=("Segoe UI", 10),
            ).pack(fill="both", expand=True, padx=20, pady=20)
        else:
            tk.Label(
                dialog, image=self.reference_image, bg=BG,
                text="Design reference only — JARVIS controls remain native, functional widgets.",
                compound="top", fg=MUTED, font=("Segoe UI", 9),
            ).pack(fill="both", expand=True, padx=12, pady=12)
        self._button(dialog, "Close", dialog.destroy, primary=True).pack(pady=(0, 10))
        dialog.focus_set()

    def _toggle_fullscreen(self) -> None:
        value = bool(self.root.attributes("-fullscreen"))
        self.root.attributes("-fullscreen", not value)

    def _launch_app(self, app_name: str) -> None:
        names = {
            "notepad": "Notepad",
            "calculator": "Calculator",
            "calc": "Calculator",
            "paint": "Paint",
            "browser": "the default browser",
        }
        name = names.get(app_name.lower(), app_name)
        result = run_command(f"open {app_name}") if app_name.lower() != "browser" else None
        if app_name.lower() == "browser":
            import webbrowser

            try:
                opened = webbrowser.open("about:blank", new=2)
            except Exception:
                logging.exception("Could not open the default browser")
                opened = False
            result = "Opened the default browser." if opened else "Windows couldn't open the default browser."
        if result is None:
            result = f"Application '{name}' is not on the approved launch list."
        self._show_action_result(result)

    def _show_action_result(self, message: str) -> None:
        if hasattr(self, "chat"):
            self._append_message("JARVIS", message, "assistant", persist=False)
        self.state_label.configure(text="SYSTEM READY", fg=CYAN)

    def _open_folder(self) -> None:
        folder = filedialog.askdirectory(title="Choose a folder to open", parent=self.root)
        if not folder:
            return
        try:
            if not hasattr(os, "startfile"):
                raise OSError("This action requires Windows.")
            os.startfile(folder)
            self._show_action_result(f"Opened folder: {folder}")
        except OSError as error:
            messagebox.showerror("Could not open folder", f"Windows couldn't open that folder.\n{error}", parent=self.root)

    def _prompt_website(self) -> None:
        from tkinter import simpledialog

        address = simpledialog.askstring("Open website", "Enter a website URL:", parent=self.root)
        if address:
            from jarvis.web_search import open_website

            self._show_action_result(open_website(address))

    def _start_file_search(self) -> None:
        self.input.delete(0, "end")
        self.input.insert(0, "search files")
        self._send()

    def _perform_search(self) -> None:
        query = self.web_query.get().strip()
        if not query:
            messagebox.showinfo("Web search", "Enter a search query first.", parent=self.root)
            return
        try:
            self.storage.add_search(query)
            result = open_search(query)
        except sqlite3.Error:
            logging.exception("Could not save search history")
            from jarvis.web_search import open_search

            result = open_search(query)
        self._refresh_searches()
        self._show_action_result(result)

    def _repeat_search(self, _event=None) -> None:
        selection = self.search_list.curselection()
        if not selection:
            return
        query = self.search_list.get(selection[0])
        self.web_query.delete(0, "end")
        self.web_query.insert(0, query)
        self._perform_search()

    def _refresh_searches(self) -> None:
        if not hasattr(self, "search_list"):
            return
        self.search_results = self.storage.get_searches()
        self.search_list.delete(0, "end")
        for query in self.search_results:
            self.search_list.insert("end", query)

    def _build_notes_refresh(self) -> None:
        self._refresh_notes()
        self._refresh_reminders()

    def _delete_reminder(self) -> None:
        selection = self.reminders_list.curselection()
        if not selection:
            messagebox.showinfo("Reminder", "Select a reminder first.", parent=self.root)
            return
        reminder = self.reminder_items[selection[0]]
        if not messagebox.askyesno(
            "Delete reminder",
            f"Permanently delete '{reminder['title']}'?",
            parent=self.root,
        ):
            return
        try:
            self.reminder_service.delete(int(reminder["id"]))
        except sqlite3.Error:
            logging.exception("Could not delete reminder")
            messagebox.showerror("Reminder", "JARVIS couldn't delete that reminder.", parent=self.root)
            return
        self._refresh_reminders()

    def _refresh_notes(self) -> None:
        if not hasattr(self, "notes_list"):
            return
        try:
            self.note_items = self.notes_service.search(self.note_search.get())
        except sqlite3.Error:
            logging.exception("Could not load notes")
            return
        self.notes_list.delete(0, "end")
        for note in self.note_items:
            self.notes_list.insert("end", str(note["title"]))

    def _select_note(self, _event=None) -> None:
        selection = self.notes_list.curselection()
        if not selection:
            return
        note = self.note_items[selection[0]]
        self.current_note_id = int(note["id"])
        self.note_title.delete(0, "end")
        self.note_title.insert(0, str(note["title"]))
        self.note_body.delete("1.0", "end")
        self.note_body.insert("1.0", str(note["body"]))
        self.note_timestamp.configure(
            text=f"Created {note['created_at']} · Modified {note['updated_at']}"
        )

    def _new_note(self) -> None:
        self._show_page("Notes")
        self.current_note_id = None
        self.note_title.delete(0, "end")
        self.note_body.delete("1.0", "end")
        self.note_timestamp.configure(text="New note")
        self.note_title.focus_set()

    def _save_note(self) -> None:
        try:
            note_id = getattr(self, "current_note_id", None)
            saved_id = self.notes_service.save(
                self.note_title.get(),
                self.note_body.get("1.0", "end"),
                note_id,
            )
        except ValueError as error:
            messagebox.showerror("Note not saved", str(error), parent=self.root)
            return
        except sqlite3.Error:
            logging.exception("Could not save note")
            messagebox.showerror("Note not saved", "JARVIS couldn't write this note to local storage.", parent=self.root)
            return
        self.current_note_id = saved_id
        self._refresh_notes()
        self._refresh_home_summary()

    def _delete_note(self) -> None:
        note_id = getattr(self, "current_note_id", None)
        if note_id is None:
            messagebox.showinfo("Delete note", "Select a saved note first.", parent=self.root)
            return
        if not messagebox.askyesno("Delete note", "Permanently delete this note?", parent=self.root):
            return
        try:
            self.notes_service.delete(note_id)
        except sqlite3.Error:
            logging.exception("Could not delete note")
            messagebox.showerror("Delete note", "JARVIS couldn't delete this note.", parent=self.root)
            return
        self.current_note_id = None
        self.note_title.delete(0, "end")
        self.note_body.delete("1.0", "end")
        self.note_timestamp.configure(text="Not saved")
        self._refresh_notes()
        self._refresh_home_summary()

    def _add_reminder(self) -> None:
        try:
            reminder_id = getattr(self, "current_reminder_id", None)
            details = self.reminder_details.get().strip()
            if details == "Details (optional)":
                details = ""
            self.reminder_service.create(
                self.reminder_title.get(), self.reminder_due.get(),
                details, reminder_id,
            )
        except ValueError as error:
            messagebox.showerror("Reminder not saved", str(error), parent=self.root)
            return
        except sqlite3.Error:
            logging.exception("Could not save reminder")
            messagebox.showerror("Reminder not saved", "JARVIS couldn't save the reminder locally.", parent=self.root)
            return
        self.reminder_title.delete(0, "end")
        self.reminder_due.delete(0, "end")
        self.reminder_due.insert(0, "YYYY-MM-DD HH:MM")
        self.reminder_details.delete(0, "end")
        self.reminder_details.insert(0, "Details (optional)")
        self.current_reminder_id = None
        self._refresh_reminders()
        self._refresh_home_summary()

    def _refresh_reminders(self) -> None:
        if not hasattr(self, "reminders_list"):
            return
        try:
            self.reminder_items = self.storage.get_reminders()
        except sqlite3.Error:
            logging.exception("Could not load reminders")
            return
        self.reminders_list.delete(0, "end")
        for reminder in self.reminder_items:
            mark = "✓" if reminder["completed"] else "○"
            self.reminders_list.insert("end", f"{mark} {reminder['due_at']} — {reminder['title']}")
        upcoming = self.reminder_service.upcoming()
        short = [f"{item['due_at']} · {item['title']}" for item in upcoming[:3]]
        self.reminder_summary.configure(text="\n".join(short) if short else "No upcoming reminders")
        self._refresh_home_summary()

    def _edit_reminder(self) -> None:
        selection = self.reminders_list.curselection()
        if not selection:
            messagebox.showinfo("Reminder", "Select a reminder to edit.", parent=self.root)
            return
        reminder = self.reminder_items[selection[0]]
        self.current_reminder_id = int(reminder["id"])
        self.reminder_title.delete(0, "end")
        self.reminder_title.insert(0, str(reminder["title"]))
        self.reminder_due.delete(0, "end")
        self.reminder_due.insert(0, str(reminder["due_at"]))
        self.reminder_details.delete(0, "end")
        self.reminder_details.insert(0, str(reminder["details"]))
        self.reminder_title.focus_set()

    def _complete_reminder(self) -> None:
        selection = self.reminders_list.curselection()
        if not selection:
            messagebox.showinfo("Reminder", "Select a reminder first.", parent=self.root)
            return
        reminder = self.reminder_items[selection[0]]
        try:
            self.reminder_service.complete(int(reminder["id"]), not bool(reminder["completed"]))
        except sqlite3.Error:
            logging.exception("Could not update reminder")
            messagebox.showerror("Reminder", "JARVIS couldn't update that reminder.", parent=self.root)
            return
        self._refresh_reminders()

    def _refresh_shortcuts(self) -> None:
        if not hasattr(self, "shortcuts_list"):
            return
        try:
            self.shortcut_items = self.storage.get_shortcuts()
        except sqlite3.Error:
            logging.exception("Could not load application shortcuts")
            return
        self.shortcuts_list.delete(0, "end")
        for shortcut in self.shortcut_items:
            self.shortcuts_list.insert("end", f"{shortcut['name']}  ·  {shortcut['path']}")

    def _add_shortcut(self) -> None:
        path = filedialog.askopenfilename(
            title="Choose an application executable",
            filetypes=(("Windows applications", "*.exe"), ("All files", "*.*")),
            parent=self.root,
        )
        if not path:
            return
        from tkinter import simpledialog

        default = Path(path).stem
        name = simpledialog.askstring("Application shortcut", "Shortcut name:", initialvalue=default, parent=self.root)
        if not name or not name.strip():
            return
        try:
            self.storage.save_shortcut(name.strip(), path)
        except sqlite3.Error:
            logging.exception("Could not save application shortcut")
            messagebox.showerror("Shortcut", "JARVIS couldn't save this shortcut.", parent=self.root)
            return
        self._refresh_shortcuts()

    def _remove_shortcut(self) -> None:
        selection = self.shortcuts_list.curselection()
        if not selection:
            messagebox.showinfo("Shortcut", "Select a shortcut to remove.", parent=self.root)
            return
        item = self.shortcut_items[selection[0]]
        if not messagebox.askyesno("Remove shortcut", f"Remove '{item['name']}' from JARVIS?", parent=self.root):
            return
        try:
            self.storage.delete_shortcut(int(item["id"]))
        except sqlite3.Error:
            logging.exception("Could not remove application shortcut")
            messagebox.showerror("Shortcut", "JARVIS couldn't remove that shortcut.", parent=self.root)
            return
        self._refresh_shortcuts()

    def _launch_selected_shortcut(self, _event=None) -> None:
        selection = self.shortcuts_list.curselection()
        if not selection:
            return
        path = Path(str(self.shortcut_items[selection[0]]["path"]))
        if not path.is_file():
            messagebox.showerror("Application unavailable", f"This shortcut target no longer exists:\n{path}", parent=self.root)
            return
        try:
            subprocess.Popen([str(path)], shell=False, cwd=str(path.parent))
        except OSError as error:
            messagebox.showerror("Application unavailable", f"Windows couldn't start the selected application.\n{error}", parent=self.root)

    def _refresh_system(self) -> None:
        if self.system_refresh_pending:
            return
        self.system_refresh_pending = True
        threading.Thread(target=self._system_worker, daemon=True).start()

    def _system_worker(self) -> None:
        try:
            snapshot = collect_system_snapshot()
            self.events.put(("system", snapshot))
            try:
                import speech_recognition
                microphone_status = (
                    "Available" if speech_recognition.Microphone.list_microphone_names()
                    else "No microphone devices found"
                )
            except Exception:
                microphone_status = "Unavailable"
            self.events.put(("system_voice", microphone_status))
        except Exception:
            logging.exception("Could not collect system information")
            self.events.put(("system_error", "System metrics are currently unavailable."))

    def _render_system(self, snapshot: SystemSnapshot) -> None:
        self.system_snapshot = snapshot
        def metric(value, suffix=""):
            return f"{value:.0f}{suffix}" if value is not None else "Unavailable"
        lines = [
            f"APPLICATION\nJARVIS AI 1.0.0 · Python {sys.version.split()[0]}",
            f"OPERATING SYSTEM\n{snapshot.operating_system}",
            f"PROCESSOR\n{snapshot.processor}",
            f"CPU UTILIZATION\n{metric(snapshot.cpu_percent, '%')}",
            f"MEMORY\n{metric(snapshot.memory_percent, '%')}  ·  "
            f"{snapshot.memory_used_gb:.1f} / {snapshot.memory_total_gb:.1f} GiB"
            if snapshot.memory_percent is not None else "MEMORY\nUnavailable",
            f"DISK\n{metric(snapshot.disk_percent, '%')}  ·  "
            f"{snapshot.disk_used_gb:.1f} / {snapshot.disk_total_gb:.1f} GiB"
            if snapshot.disk_percent is not None else "DISK\nUnavailable",
            f"BATTERY\n{snapshot.battery_percent:.0f}% · "
            f"{'Charging' if snapshot.battery_plugged else 'On battery'}"
            if snapshot.battery_percent is not None else "BATTERY\nNot present or unavailable",
        ]
        self.system_text.configure(state="normal")
        self.system_text.delete("1.0", "end")
        self.system_text.insert("1.0", "\n\n".join(lines))
        self.system_text.configure(state="disabled")
        self.system_refresh_pending = False
        self.dashboard_cpu.configure(text=metric(snapshot.cpu_percent, "%"))
        self.dashboard_memory.configure(
            text=f"{metric(snapshot.memory_percent, '%')} · "
                 f"{snapshot.memory_used_gb:.1f}/{snapshot.memory_total_gb:.1f} GiB"
            if snapshot.memory_percent is not None else "Unavailable"
        )
        self.dashboard_disk.configure(
            text=f"{metric(snapshot.disk_percent, '%')} · "
                 f"{snapshot.disk_used_gb:.1f}/{snapshot.disk_total_gb:.1f} GiB"
            if snapshot.disk_percent is not None else "Unavailable"
        )
        self.dashboard_battery.configure(
            text=f"{snapshot.battery_percent:.0f}% · "
                 f"{'Charging' if snapshot.battery_plugged else 'On battery'}"
            if snapshot.battery_percent is not None else "Not present"
        )

    def _refresh_dashboard(self) -> None:
        self._refresh_system()
        self._update_voice_status()
        if hasattr(self, "dashboard_mic"):
            status = "Listening" if self.listening else "Idle · not recording"
            self.dashboard_mic.configure(text=status)
            self.dashboard_tts.configure(
                text="Ready" if self.voice_output.available else "Unavailable"
            )
            if not self._get_api_key():
                self.dashboard_api.configure(text="Not configured")
                self.header_status.configure(text="● API NOT CONFIGURED", fg=MUTED)
        self.root.after(5000, self._refresh_dashboard)

    def _new_page(self, name: str, title: str) -> tk.Frame:
        page = tk.Frame(self.center, bg=BG)
        page.pack_propagate(False)
        tk.Label(page, text=title, fg=CYAN, bg=BG, font=("Segoe UI", 16, "bold")).pack(anchor="w", pady=(4, 12))
        self.pages[name] = page
        return page

    def _build_notes_page(self) -> None:
        page = self._new_page("Notes", "NOTES & REMINDERS")
        toolbar = tk.Frame(page, bg=BG)
        toolbar.pack(fill="x", pady=(0, 8))
        self.note_search = ttk.Entry(toolbar, style="Jarvis.TEntry")
        self.note_search.pack(side="left", fill="x", expand=True, padx=(0, 6))
        self.note_search.bind("<KeyRelease>", lambda _event: self._refresh_notes())
        self._button(toolbar, "New note", self._new_note, primary=True).pack(side="left")
        content = tk.Frame(page, bg=BG)
        content.pack(fill="both", expand=True)
        list_panel = tk.Frame(content, bg=PANEL, width=195)
        list_panel.pack(side="left", fill="y", padx=(0, 8))
        list_panel.pack_propagate(False)
        self.notes_list = tk.Listbox(list_panel, bg=PANEL, fg=TEXT, selectbackground="#16475d", relief="flat", font=("Segoe UI", 9))
        self.notes_list.pack(fill="both", expand=True, padx=5, pady=5)
        self.notes_list.bind("<<ListboxSelect>>", self._select_note)
        editor = tk.Frame(content, bg=PANEL)
        editor.pack(side="left", fill="both", expand=True)
        self.note_title = ttk.Entry(editor, style="Jarvis.TEntry")
        self.note_title.pack(fill="x", padx=10, pady=(10, 6))
        self.note_body = tk.Text(editor, bg=PANEL_LIGHT, fg=TEXT, insertbackground=TEXT, relief="flat", wrap="word", font=("Segoe UI", 10))
        self.note_body.pack(fill="both", expand=True, padx=10, pady=4)
        self.note_timestamp = tk.Label(editor, text="Not saved", fg=MUTED, bg=PANEL, font=("Segoe UI", 8))
        self.note_timestamp.pack(anchor="w", padx=10, pady=(2, 0))
        actions = tk.Frame(editor, bg=PANEL)
        actions.pack(fill="x", padx=10, pady=(4, 10))
        self._button(actions, "Save note", self._save_note, primary=True).pack(side="left")
        self._button(actions, "Delete note", self._delete_note).pack(side="left", padx=6)
        reminder = tk.LabelFrame(page, text="Reminder (stored locally; app must be open to view it)", bg=PANEL, fg=CYAN, font=("Segoe UI", 8))
        reminder.pack(fill="x", pady=(8, 0))
        self.reminder_title = ttk.Entry(reminder, style="Jarvis.TEntry")
        self.reminder_title.insert(0, "Reminder title")
        self.reminder_title.pack(side="left", fill="x", expand=True, padx=6, pady=6)
        self.reminder_due = ttk.Entry(reminder, style="Jarvis.TEntry", width=22)
        self.reminder_due.insert(0, "YYYY-MM-DD HH:MM")
        self.reminder_due.pack(side="left", padx=6, pady=6)
        self.reminder_details = ttk.Entry(reminder, style="Jarvis.TEntry")
        self.reminder_details.insert(0, "Details (optional)")
        self.reminder_details.pack(side="left", fill="x", expand=True, padx=6, pady=6)
        self._button(reminder, "Save", self._add_reminder, primary=True, compact=True).pack(side="left", padx=6)
        self.reminders_list = tk.Listbox(page, height=4, bg=PANEL, fg=TEXT, selectbackground="#16475d", relief="flat", font=("Segoe UI", 8))
        self.reminders_list.pack(fill="x", pady=(6, 0))
        reminder_actions = tk.Frame(page, bg=BG)
        reminder_actions.pack(fill="x", pady=(4, 0))
        self._button(reminder_actions, "Complete / reopen", self._complete_reminder, compact=True).pack(side="left")
        self._button(reminder_actions, "Edit selected", self._edit_reminder, compact=True).pack(side="left", padx=6)
        self._button(reminder_actions, "Delete reminder", self._delete_reminder, compact=True, danger=True).pack(side="left", padx=6)

    def _build_search_page(self) -> None:
        page = self._new_page("Web Search", "WEB SEARCH")
        tk.Label(page, text="Search opens your browser. JARVIS does not claim to verify or summarize live results.", fg=MUTED, bg=BG, wraplength=570, justify="left").pack(anchor="w", pady=(0, 10))
        row = tk.Frame(page, bg=BG)
        row.pack(fill="x")
        self.web_query = ttk.Entry(row, style="Jarvis.TEntry")
        self.web_query.pack(side="left", fill="x", expand=True, padx=(0, 6), ipady=4)
        self.web_query.bind("<Return>", lambda _event: self._perform_search())
        self._button(row, "Search Web", self._perform_search, primary=True).pack(side="left")
        tk.Label(page, text="RECENT SEARCHES", fg=MUTED, bg=BG, font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(18, 6))
        self.search_list = tk.Listbox(page, bg=PANEL, fg=TEXT, selectbackground="#16475d", relief="flat", font=("Segoe UI", 10))
        self.search_list.pack(fill="both", expand=True)
        self.search_list.bind("<Double-Button-1>", self._repeat_search)
        self._button(page, "Search selected again", self._repeat_search, compact=True).pack(anchor="e", pady=6)

    def _build_apps_page(self) -> None:
        page = self._new_page("Applications", "APPLICATIONS")
        tk.Label(page, text="Approved Windows applications and user-selected shortcuts. Shortcuts run only after you add them.", fg=MUTED, bg=BG, wraplength=570, justify="left").pack(anchor="w", pady=(0, 10))
        quick = tk.Frame(page, bg=BG)
        quick.pack(fill="x")
        for name in ("Notepad", "Calculator", "Paint", "Browser"):
            self._button(quick, name, lambda app=name.lower(): self._launch_app(app)).pack(side="left", padx=(0, 6))
        row = tk.Frame(page, bg=BG)
        row.pack(fill="x", pady=(16, 6))
        self._button(row, "Add executable shortcut…", self._add_shortcut, primary=True).pack(side="left")
        self._button(row, "Open selected", self._launch_selected_shortcut).pack(side="left", padx=6)
        self._button(row, "Remove selected", self._remove_shortcut).pack(side="left", padx=6)
        self.shortcuts_list = tk.Listbox(page, bg=PANEL, fg=TEXT, selectbackground="#16475d", relief="flat", font=("Segoe UI", 10))
        self.shortcuts_list.pack(fill="both", expand=True)
        self.shortcuts_list.bind("<Double-Button-1>", self._launch_selected_shortcut)

    def _build_system_page(self) -> None:
        page = self._new_page("System Info", "SYSTEM INFORMATION")
        self.system_text = tk.Text(page, wrap="word", bg=PANEL, fg=TEXT, relief="flat", padx=14, pady=14, font=("Segoe UI", 10), state="disabled")
        self.system_text.pack(fill="both", expand=True)
        self._button(page, "Refresh now", self._refresh_system, primary=True).pack(anchor="e", pady=(8, 0))

    def _build_automation_page(self) -> None:
        page = self._new_page("Automation", "AUTOMATION & TOOLS")
        tk.Label(page, text="Supported actions are explicit and user initiated. JARVIS never runs arbitrary AI-generated terminal commands.", fg=MUTED, bg=BG, wraplength=570, justify="left").pack(anchor="w", pady=(0, 10))
        for title, description, callback in (
            ("Open Notepad", "Launch the allow-listed Windows text editor.", lambda: self._launch_app("notepad")),
            ("Open Calculator", "Launch the allow-listed Windows calculator.", lambda: self._launch_app("calculator")),
            ("Open Paint", "Launch Paint when it is installed.", lambda: self._launch_app("paint")),
            ("Open website", "Enter a URL and open it in your default browser.", self._prompt_website),
            ("Create a note", "Save a note locally in the application database.", self._new_note),
            ("Open selected folder", "Choose a folder to open in Windows Explorer.", self._open_folder),
            ("Search files", "Select a directory and list up to 500 file names.", self._start_file_search),
            ("System information", "Show real CPU, memory, disk, battery, and Windows metrics.", lambda: self._show_page("System Info")),
        ):
            card = tk.Frame(page, bg=PANEL, highlightbackground="#1c4056", highlightthickness=1)
            card.pack(fill="x", pady=3)
            text = tk.Frame(card, bg=PANEL)
            text.pack(side="left", fill="x", expand=True, padx=10, pady=8)
            tk.Label(text, text=title, fg=TEXT, bg=PANEL, font=("Segoe UI", 10, "bold")).pack(anchor="w")
            tk.Label(text, text=description, fg=MUTED, bg=PANEL, font=("Segoe UI", 8)).pack(anchor="w")
            self._button(card, "Run", callback, compact=True, primary=True).pack(side="right", padx=8, pady=8)

    def _button(self, parent: tk.Widget, text: str, command, primary: bool = False, compact: bool = False, danger: bool = False) -> tk.Button:
        bg = "#123c52" if primary else PANEL_LIGHT
        fg = CYAN if primary else (RED if danger else TEXT)
        return tk.Button(
            parent, text=text, command=command, bg=bg, fg=fg,
            activebackground="#1d4963", activeforeground="white",
            relief="flat", bd=0, padx=10 if compact else 13,
            pady=6 if compact else 8, cursor="hand2",
            font=("Segoe UI", 9, "bold"),
        )

    def _append_message(self, name: str, content: str, role: str, persist: bool = True) -> None:
        self.chat.configure(state="normal")
        tag = "user" if role == "user" else ("assistant" if role == "assistant" else "system")
        self.chat.insert("end", f"{datetime.now().astimezone().strftime('%H:%M')}  ", "timestamp")
        self.chat.insert("end", f"{name}\n", tag)
        self.chat.insert("end", content.strip() + "\n\n", "body")
        self.chat.configure(state="disabled")
        self.chat.see("end")
        if persist and self._history_enabled():
            try:
                self.storage.add_message(role, content)
            except sqlite3.Error:
                logging.exception("Could not save conversation history")
                messagebox.showwarning(
                    "Conversation not saved",
                    "JARVIS couldn't save this message to local history. It remains visible for this session; check disk space and folder permissions.",
                    parent=self.root,
                )

    def _load_history(self) -> None:
        if not self._history_enabled():
            return
        try:
            self.messages = self.storage.get_messages()
            timestamps = self.storage.message_timestamps()
        except sqlite3.Error:
            logging.exception("Could not load conversation history")
            messagebox.showwarning(
                "History unavailable",
                "JARVIS couldn't read saved conversation history. The current session can still continue.",
                parent=self.root,
            )
            return
        if not self.messages:
            return
        self.chat.configure(state="normal")
        self.chat.delete("1.0", "end")
        self.chat.configure(state="disabled")
        for index, item in enumerate(self.messages):
            role = item["role"]
            self.chat.configure(state="normal")
            try:
                stamp = datetime.fromisoformat(timestamps[index]).astimezone().strftime("%H:%M")
            except (ValueError, IndexError):
                stamp = ""
            self.chat.insert("end", f"{stamp}  ", "timestamp")
            self.chat.insert("end", f"{'YOU' if role == 'user' else 'JARVIS'}\n", role)
            self.chat.insert("end", item["content"].strip() + "\n\n", "body")
            self.chat.configure(state="disabled")
        self.chat.see("end")

    def _history_enabled(self) -> bool:
        return bool(self.settings.get("save_history", False))

    def _send(self) -> None:
        if self.busy:
            return
        text = self.input.get().strip()
        if not text:
            return
        self.input.delete(0, "end")
        self._append_message("YOU", text, "user")
        self.messages.append({"role": "user", "content": text})
        open_match = re.fullmatch(r"(?:open|show)\s+(?:a\s+)?(file|folder)[?.!]*", text, re.IGNORECASE)
        if open_match:
            selected = (
                filedialog.askopenfilename(title="Choose a file to open", parent=self.root)
                if open_match.group(1).lower() == "file"
                else filedialog.askdirectory(title="Choose a folder to open", parent=self.root)
            )
            if not selected:
                result = "Selection cancelled."
            elif not hasattr(os, "startfile"):
                result = "Opening selected files and folders is supported on Windows only."
            else:
                try:
                    os.startfile(selected)
                    result = f"Opened the selected {'file' if open_match.group(1).lower() == 'file' else 'folder'}."
                except OSError:
                    result = "Windows couldn't open that selection. Check that the file exists and your account has access."
            self._append_message("JARVIS", result, "assistant")
            self.messages.append({"role": "assistant", "content": result})
            return
        if re.fullmatch(r"(?:search|find)\s+(?:for\s+)?files?[?.!]*", text, re.IGNORECASE):
            folder = filedialog.askdirectory(title="Choose a folder to search", parent=self.root)
            if not folder:
                self._append_message("JARVIS", "File search cancelled.", "assistant")
                return
            self._set_busy(True, "SEARCHING FILES")
            threading.Thread(target=self._file_search_worker, args=(folder,), daemon=True).start()
            return
        if re.fullmatch(r"(?:show|get|check)\s+(?:my\s+)?system\s+(?:and\s+)?network\s+status[?.!]*", text, re.IGNORECASE):
            self._set_busy(True, "READING SYSTEM STATUS")
            threading.Thread(target=self._local_system_worker, daemon=True).start()
            return
        local_result = run_command(text)
        if local_result is not None:
            self._append_message("JARVIS", local_result, "assistant")
            self.messages.append({"role": "assistant", "content": local_result})
            self.state_label.configure(text="SYSTEM READY", fg=CYAN)
            return
        try:
            client = self._make_client()
        except ValueError as error:
            self._append_message("JARVIS", str(error), "assistant")
            return
        self._set_busy(True, "THINKING")
        history = self.messages[-40:].copy()
        threading.Thread(target=self._chat_worker, args=(client, history), daemon=True).start()

    def _file_search_worker(self, folder: str) -> None:
        try:
            result = run_command("search files", choose_directory=lambda: folder)
            self.events.put(("local", result or "File search did not return a result."))
        except Exception:
            logging.exception("Unexpected file search failure")
            self.events.put(("local", "File search failed. Check folder permissions and try again."))

    def _local_system_worker(self) -> None:
        try:
            result = run_command("show system and network status")
            self.events.put(("local", result or "System information is unavailable."))
        except Exception:
            logging.exception("Could not read system information")
            self.events.put(("local", "System information is currently unavailable."))

    def _chat_worker(self, client: AIClient, history: list[dict[str, str]]) -> None:
        response: list[str] = []
        try:
            for chunk in client.chat_stream(history):
                response.append(chunk)
                self.events.put(("stream_chunk", chunk))
            self.events.put(("stream_complete", "".join(response)))
        except AIError as error:
            self.events.put(("error", str(error)))
        except Exception:
            logging.exception("Unexpected AI request failure")
            self.events.put(("error", "An unexpected error occurred while contacting the AI provider. See the local log for diagnostics."))

    def _make_client(self) -> AIClient:
        key = self._get_api_key()
        base = str(self.settings.get("base_url", DEFAULT_BASE_URL)).strip()
        model = str(self.settings.get("model", DEFAULT_MODEL)).strip()
        if not model:
            raise ValueError("Enter a model name in Settings.")
        try:
            temperature = float(self.settings.get("temperature", 0.7))
            if not 0 <= temperature <= 2:
                raise ValueError
        except (TypeError, ValueError):
            raise ValueError("Temperature must be a number from 0 to 2.") from None
        prompt = str(self.settings.get("system_prompt", SYSTEM_PROMPT)).strip() or SYSTEM_PROMPT
        return AIClient(AISettings(key, base, model, temperature, prompt))

    def _get_api_key(self) -> str:
        stored = None
        if keyring is not None:
            try:
                stored = keyring.get_password(KEYRING_SERVICE, KEYRING_USERNAME)
            except keyring.errors.KeyringError:
                logging.warning("Windows Credential Manager could not read the configured API key.")
        return stored or os.environ.get("OPENAI_API_KEY", "")

    def _toggle_listening(self) -> None:
        if self.listening:
            self.listening = False
            if self.listen_cancel is not None:
                self.listen_cancel.set()
            self.mic_button.configure(text="Stopping…", state="disabled")
            self.mic_status.configure(text="● Stopping microphone…", fg=BLUE)
            self.state_label.configure(text="STOPPING LISTENING", fg=BLUE)
            return
        if self.busy:
            return
        self.listening = True
        self.listen_cancel = threading.Event()
        self.mic_button.configure(text="Stop listening")
        self.mic_status.configure(text="● Listening…", fg=GREEN)
        self.state_label.configure(text="LISTENING — speak now", fg=GREEN)
        threading.Thread(target=self._listen_worker, args=(self.listen_cancel,), daemon=True).start()

    def _listen_worker(self, cancelled: threading.Event) -> None:
        try:
            text = self.voice_input.listen(cancelled)
            self.events.put(("voice_cancelled", None) if cancelled.is_set() else ("recognized", text))
        except RuntimeError as error:
            if cancelled.is_set():
                self.events.put(("voice_cancelled", None))
            else:
                self.events.put(("voice_error", str(error)))
        except Exception:
            logging.exception("Unexpected microphone failure")
            if cancelled.is_set():
                self.events.put(("voice_cancelled", None))
            else:
                self.events.put(("voice_error", "Microphone recognition failed. Check the device and Windows privacy permissions."))

    def _stop_speaking(self) -> None:
        self.voice_output.stop()
        self.speaking = False
        self.state_label.configure(text="SYSTEM READY", fg=CYAN)

    def _poll_events(self) -> None:
        try:
            while True:
                event, value = self.events.get_nowait()
                if event == "stream_chunk":
                    self._append_stream_chunk(str(value))
                elif event == "stream_complete":
                    response = str(value)
                    if self.stream_in_progress:
                        self.chat.configure(state="normal")
                        self.chat.insert("end", "\n\n")
                        self.chat.configure(state="disabled")
                        self.stream_in_progress = False
                    if not response:
                        self._append_message("JARVIS", "The provider returned an empty answer.", "system")
                    else:
                        self.messages.append({"role": "assistant", "content": response})
                        if self._history_enabled():
                            try:
                                self.storage.add_message("assistant", response)
                            except sqlite3.Error:
                                logging.exception("Could not save streamed conversation response")
                        self._set_busy(False, "SPEAKING")
                        self.speaking = True
                        self.ai_status.configure(text="● AI connected", fg=GREEN)
                        self.dashboard_api.configure(text="Connected this session")
                        self.header_status.configure(text="● AI RESPONSE RECEIVED", fg=GREEN)
                        self.voice_output.speak(response)
                    if not response:
                        self._set_busy(False, "SYSTEM READY")
                elif event == "chat":
                    response = str(value)
                    self._append_message("JARVIS", response, "assistant")
                    self.messages.append({"role": "assistant", "content": response})
                    self._set_busy(False, "SPEAKING")
                    self.speaking = True
                    self.ai_status.configure(text="● AI connected", fg=GREEN)
                    self.voice_output.speak(response)
                elif event == "error":
                    if self.stream_in_progress:
                        self.chat.configure(state="normal")
                        self.chat.insert("end", "\n\n")
                        self.chat.configure(state="disabled")
                        self.stream_in_progress = False
                    self._append_message("JARVIS", str(value), "assistant")
                    self._set_busy(False, "SYSTEM READY")
                    self.ai_status.configure(text="● AI request failed", fg=RED)
                    self.dashboard_api.configure(text="Request failed")
                    self.header_status.configure(text="● AI REQUEST FAILED", fg=RED)
                elif event == "local":
                    self._append_message("JARVIS", str(value), "assistant")
                    self.messages.append({"role": "assistant", "content": str(value)})
                    self._set_busy(False, "SYSTEM READY")
                elif event == "system":
                    self._render_system(value)
                elif event == "system_voice":
                    if self.system_snapshot is not None:
                        self.system_text.configure(state="normal")
                        self.system_text.insert(
                            "end",
                            f"\n\nMICROPHONE\n{value}"
                            f"\n\nSPEECH SYNTHESIS\n"
                            f"{'Available' if self.voice_output.available else 'Unavailable'}"
                            f"\n\nAI PROVIDER\n{self.settings.get('provider', 'Not configured')}",
                        )
                        self.system_text.configure(state="disabled")
                elif event == "system_error":
                    self.system_refresh_pending = False
                    self.dashboard_cpu.configure(text="Unavailable")
                    self.dashboard_memory.configure(text="Unavailable")
                    self.dashboard_disk.configure(text="Unavailable")
                    self.dashboard_battery.configure(text="Unavailable")
                    self.system_text.configure(state="normal")
                    self.system_text.delete("1.0", "end")
                    self.system_text.insert("1.0", str(value))
                    self.system_text.configure(state="disabled")
                elif event == "settings_test":
                    status, result, succeeded = value
                    try:
                        status.configure(text=str(result), fg=GREEN if succeeded else RED)
                        if succeeded:
                            self.ai_status.configure(text="● Connection test passed", fg=GREEN)
                            self.dashboard_api.configure(text="Test passed")
                            self.header_status.configure(text="● API VERIFIED", fg=GREEN)
                        else:
                            self.dashboard_api.configure(text="Test failed")
                            self.header_status.configure(text="● API TEST FAILED", fg=RED)
                    except tk.TclError:
                        pass
                elif event == "spoken":
                    self.speaking = False
                    if not self.busy and not self.listening:
                        self.state_label.configure(text="SYSTEM READY", fg=CYAN)
                elif event == "recognized":
                    if not self.listening:
                        continue
                    self.listening = False
                    self.mic_button.configure(text="🎙  Speak")
                    self.mic_button.configure(state="normal")
                    self.mic_status.configure(text="● Mic idle", fg=MUTED)
                    self.input.insert(0, str(value))
                    self._send()
                elif event == "voice_cancelled":
                    self.mic_button.configure(text="🎙  Speak", state="normal")
                    self.mic_status.configure(text="● Mic idle", fg=MUTED)
                    self.state_label.configure(text="SYSTEM READY", fg=CYAN)
                elif event == "voice_error":
                    self.listening = False
                    self.mic_button.configure(text="🎙  Speak", state="normal")
                    self.mic_status.configure(text="● Mic unavailable", fg=RED)
                    self._append_message("JARVIS", str(value), "system")
                    self.state_label.configure(text="SYSTEM READY", fg=CYAN)
        except queue.Empty:
            pass
        self._update_voice_status()
        self.root.after(100, self._poll_events)

    def _append_stream_chunk(self, chunk: str) -> None:
        if self.typing_visible:
            self.chat.configure(state="normal")
            start = self.chat.search("JARVIS · working…", "1.0", "end")
            if start:
                self.chat.delete(start, f"{start} lineend + 1 chars")
            self.chat.insert("end", f"{datetime.now().astimezone().strftime('%H:%M')}  ", "timestamp")
            self.chat.insert("end", "JARVIS\n", "assistant")
            self.typing_visible = False
            self.stream_in_progress = True
        self.chat.insert("end", chunk, "body")
        self.chat.configure(state="disabled")
        self.chat.see("end")

    def _set_busy(self, busy: bool, state: str) -> None:
        self.busy = busy
        self.send_button.configure(state="disabled" if busy else "normal")
        self.mic_button.configure(state="disabled" if busy else "normal")
        self.state_label.configure(text=state, fg=BLUE if busy else CYAN)
        if busy and not self.typing_visible:
            self.chat.configure(state="normal")
            self.chat.insert("end", "JARVIS · working…\n\n", "system")
            self.chat.configure(state="disabled")
            self.chat.see("end")
            self.typing_visible = True
        elif not busy and self.typing_visible:
            self.chat.configure(state="normal")
            start = self.chat.search("JARVIS · working…", "1.0", "end")
            if start:
                self.chat.delete(start, f"{start} lineend + 1 chars")
            self.chat.configure(state="disabled")
            self.typing_visible = False

    def _update_voice_status(self) -> None:
        if self.voice_output.available:
            self.tts_status.configure(text="● Speech engine ready", fg=GREEN)
        elif self.voice_output.error:
            self.tts_status.configure(text="● Speech unavailable", fg=RED)

    def _animate(self) -> None:
        self.animation_phase = (self.animation_phase + 1) % 120
        canvas = self.canvas
        canvas.delete("all")
        if hasattr(self, "home_core"):
            self.home_core.delete("all")
        if not self.animation_enabled:
            canvas.create_oval(
                canvas.winfo_width() / 2 - 38, 35,
                canvas.winfo_width() / 2 + 38, 111,
                outline=CYAN, width=2,
            )
            canvas.create_text(
                canvas.winfo_width() / 2, 73, text="J", fill=CYAN,
                font=("Segoe UI", 26, "bold"),
            )
            if hasattr(self, "home_core"):
                self.home_core.delete("all")
                self.home_core.create_oval(
                    self.home_core.winfo_width() / 2 - 68, 42,
                    self.home_core.winfo_width() / 2 + 68, 178,
                    outline=CYAN, width=2,
                )
                self.home_core.create_text(
                    self.home_core.winfo_width() / 2, 110, text="J.A.R.V.I.S.",
                    fill=TEXT, font=("Segoe UI", 14, "bold"),
                )
            self.root.after(500, self._animate)
            return
        width = max(canvas.winfo_width(), 500)
        center_x, center_y = width / 2, 73
        phase = self.animation_phase / 12
        outer = 46 + (
            2 * math.sin(phase)
            if not self.busy and not self.listening and not self.speaking
            else 5 * math.sin(phase)
        )
        color = GREEN if self.listening else (BLUE if self.busy else (CYAN if not self.speaking else "#8a9fff"))
        for radius, color_value, line_width in ((57, "#12384b", 1), (outer, color, 2), (31, "#1a5b74", 1)):
            canvas.create_oval(center_x - radius, center_y - radius, center_x + radius, center_y + radius, outline=color_value, width=line_width)
        canvas.create_oval(center_x - 8, center_y - 8, center_x + 8, center_y + 8, fill=color, outline="")
        for index in range(24):
            angle = index * 2 * math.pi / 24 + phase * (0.25 if self.busy or self.speaking else 0.1)
            radius = 68 + (5 * abs(math.sin(phase + index)) if self.busy or self.listening or self.speaking else 0)
            x = center_x + radius * math.cos(angle)
            y = center_y + radius * math.sin(angle)
            canvas.create_oval(x - 1.5, y - 1.5, x + 1.5, y + 1.5, fill="#36d9ef", outline="")
        if hasattr(self, "home_core"):
            home_width = max(self.home_core.winfo_width(), 500)
            home_x, home_y = home_width / 2, 112
            home_radius = 62 + 4 * math.sin(phase)
            self.home_core.create_oval(
                home_x - 76, home_y - 76, home_x + 76, home_y + 76,
                outline="#12384b", width=1,
            )
            self.home_core.create_oval(
                home_x - home_radius, home_y - home_radius,
                home_x + home_radius, home_y + home_radius,
                outline=color, width=2,
            )
            self.home_core.create_oval(
                home_x - 8, home_y - 8, home_x + 8, home_y + 8,
                fill=color, outline="",
            )
            self.home_core.create_text(
                home_x, home_y + 93, text=self.state_label.cget("text"),
                fill=MUTED, font=("Segoe UI", 9, "bold"),
            )
        self.root.after(250 if self.animation_enabled else 500, self._animate)

    def _open_settings(self) -> None:
        dialog = tk.Toplevel(self.root)
        dialog.title("JARVIS Settings")
        dialog.configure(bg=BG)
        dialog.resizable(False, False)
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.geometry("560x680")
        panel = tk.Frame(dialog, bg=PANEL)
        panel.pack(fill="both", expand=True, padx=16, pady=16)
        tk.Label(panel, text="AI & PRIVACY SETTINGS", bg=PANEL, fg=CYAN, font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=18, pady=(16, 8))

        provider_var = tk.StringVar(value=str(self.settings.get("provider", "OpenAI")))
        self._setting_label(panel, "Provider")
        provider = ttk.Combobox(
            panel,
            textvariable=provider_var,
            values=("OpenAI", "OpenRouter", "Custom OpenAI-compatible"),
            state="readonly",
        )
        provider.pack(fill="x", padx=18, pady=(0, 10))
        self._setting_label(panel, "API key (saved in Windows Credential Manager)")
        key_var = tk.StringVar()
        key_entry = ttk.Entry(panel, textvariable=key_var, show="•", style="Jarvis.TEntry")
        key_entry.pack(fill="x", padx=18, pady=(0, 3))
        key_state = "API key configured" if self._get_api_key() else "No API key configured"
        tk.Label(panel, text=key_state + " (environment-variable fallback supported)", bg=PANEL, fg=MUTED, font=("Segoe UI", 8)).pack(anchor="w", padx=18, pady=(0, 9))
        self._setting_label(panel, "API base URL")
        base_var = tk.StringVar(value=str(self.settings.get("base_url", DEFAULT_BASE_URL)))
        ttk.Entry(panel, textvariable=base_var, style="Jarvis.TEntry").pack(fill="x", padx=18, pady=(0, 10))

        def provider_changed(_event=None) -> None:
            default_urls = {
                "OpenAI": DEFAULT_BASE_URL,
                "OpenRouter": "https://openrouter.ai/api/v1",
            }
            if provider_var.get() in default_urls:
                base_var.set(default_urls[provider_var.get()])

        provider.bind("<<ComboboxSelected>>", provider_changed)
        self._setting_label(panel, "Model (availability depends on your API account)")
        model_var = tk.StringVar(value=str(self.settings.get("model", DEFAULT_MODEL)))
        ttk.Entry(panel, textvariable=model_var, style="Jarvis.TEntry").pack(fill="x", padx=18, pady=(0, 10))
        self._setting_label(panel, "Temperature (0–2)")
        temp_var = tk.StringVar(value=str(self.settings.get("temperature", 0.7)))
        ttk.Entry(panel, textvariable=temp_var, style="Jarvis.TEntry").pack(fill="x", padx=18, pady=(0, 10))
        self._setting_label(panel, "Voice language")
        language_values = ("en-IN — English / Hinglish", "hi-IN — Hindi")
        saved_language = str(self.settings.get("voice_language", "en-IN"))
        language_var = tk.StringVar(
            value=language_values[1] if saved_language == "hi-IN" else language_values[0]
        )
        ttk.Combobox(
            panel, textvariable=language_var, values=language_values, state="readonly"
        ).pack(fill="x", padx=18, pady=(0, 8))
        self._setting_label(panel, "Listening timeout in seconds (3–60)")
        timeout_var = tk.StringVar(value=str(self.settings.get("listening_timeout", 8)))
        ttk.Entry(panel, textvariable=timeout_var, style="Jarvis.TEntry").pack(fill="x", padx=18, pady=(0, 8))
        self._setting_label(panel, "System prompt")
        prompt = tk.Text(panel, height=4, bg=PANEL_LIGHT, fg=TEXT, insertbackground=TEXT, relief="flat", wrap="word", font=("Segoe UI", 9))
        prompt.pack(fill="x", padx=18, pady=(0, 8))
        prompt.insert("1.0", str(self.settings.get("system_prompt", SYSTEM_PROMPT)))
        history_var = tk.BooleanVar(value=self._history_enabled())
        ttk.Checkbutton(panel, text="Save conversation history on this PC", variable=history_var, style="Jarvis.TCheckbutton").pack(anchor="w", padx=18, pady=(0, 4))
        animation_var = tk.BooleanVar(value=self.animation_enabled)
        ttk.Checkbutton(panel, text="Enable animated visualizer", variable=animation_var, style="Jarvis.TCheckbutton").pack(anchor="w", padx=18, pady=(0, 4))
        self._setting_label(panel, "Startup page")
        startup_page_var = tk.StringVar(value=str(self.settings.get("startup_page", "AI Chat")))
        ttk.Combobox(
            panel, textvariable=startup_page_var, values=("AI Chat", "Home"),
            state="readonly",
        ).pack(fill="x", padx=18, pady=(0, 8))
        status = tk.Label(panel, text="Connection not tested", bg=PANEL, fg=MUTED, font=("Segoe UI", 9))
        status.pack(anchor="w", padx=18, pady=(4, 6))
        buttons = tk.Frame(panel, bg=PANEL)
        buttons.pack(fill="x", padx=18, pady=(2, 14))

        def form_settings() -> dict[str, object]:
            try:
                temperature = float(temp_var.get())
                if not 0 <= temperature <= 2:
                    raise ValueError
            except ValueError:
                raise ValueError("Temperature must be a number from 0 to 2.") from None
            base_url = base_var.get().strip()
            model_name = model_var.get().strip()
            if not base_url.startswith(("https://", "http://")) or not model_name:
                raise ValueError("Enter a valid API base URL and model name.")
            try:
                listening_timeout = int(timeout_var.get())
                if not 3 <= listening_timeout <= 60:
                    raise ValueError
            except ValueError:
                raise ValueError("Listening timeout must be a whole number from 3 to 60 seconds.") from None
            return {
                "provider": provider_var.get(),
                "base_url": base_url,
                "model": model_name,
                "temperature": temperature,
                "system_prompt": prompt.get("1.0", "end").strip() or SYSTEM_PROMPT,
                "save_history": history_var.get(),
                "animations": animation_var.get(),
                "startup_page": startup_page_var.get(),
                "voice_language": "hi-IN" if language_var.get().startswith("hi-IN") else "en-IN",
                "listening_timeout": listening_timeout,
            }

        def settings_with_key() -> AIClient:
            values = form_settings()
            key = key_var.get().strip() or self._get_api_key()
            return AIClient(AISettings(
                key, str(values["base_url"]), str(values["model"]),
                float(values["temperature"]), str(values["system_prompt"]),
            ))

        def test_connection() -> None:
            try:
                client = settings_with_key()
            except ValueError as error:
                messagebox.showerror("Settings", str(error), parent=dialog)
                return
            status.configure(text="Testing connection…", fg=BLUE)

            def worker() -> None:
                try:
                    result = client.test_connection()
                    self.events.put(("settings_test", (status, result, True)))
                except AIError as error:
                    self.events.put(("settings_test", (status, str(error), False)))
                except Exception:
                    logging.exception("Unexpected AI connection-test failure")
                    self.events.put((
                        "settings_test",
                        (status, "The connection test failed unexpectedly. Check the local diagnostic log.", False),
                    ))
            threading.Thread(target=worker, daemon=True).start()

        def save_settings() -> None:
            try:
                values = form_settings()
                if key_var.get().strip():
                    if keyring is None:
                        raise RuntimeError("The keyring package is not installed.")
                    keyring.set_password(KEYRING_SERVICE, KEYRING_USERNAME, key_var.get().strip())
                values["provider"] = provider_var.get()
                self.settings.update(values)
                self.storage.save_settings(values)
                self.animation_enabled = bool(values["animations"])
                self.voice_input.language = str(values["voice_language"])
                self.voice_input.timeout = int(values["listening_timeout"])
                if not history_var.get():
                    self.storage.clear_messages()
                    self.messages.clear()
                    self.chat.configure(state="normal")
                    self.chat.delete("1.0", "end")
                    self.chat.configure(state="disabled")
                    self._append_message("JARVIS", "History saving is off; previous local messages were deleted.", "assistant", persist=False)
                elif history_var.get():
                    self.storage.clear_messages()
                    for item in self.messages[-40:]:
                        self.storage.add_message(item["role"], item["content"])
                self.ai_status.configure(
                    text="● API key configured — connection not tested" if self._get_api_key() else "● AI not configured",
                    fg=MUTED,
                )
                self.dashboard_api.configure(
                    text="Configured · not tested" if self._get_api_key() else "API key not configured"
                )
                self.header_status.configure(
                    text="● API NOT TESTED" if self._get_api_key() else "● AI NOT CONFIGURED",
                    fg=MUTED,
                )
                dialog.destroy()
            except (RuntimeError, KEYRING_ERROR):
                messagebox.showerror(
                    "Credential Manager unavailable",
                    "Windows Credential Manager could not save the key. Set OPENAI_API_KEY for your Windows user and save settings again.",
                    parent=dialog,
                )
            except (OSError, sqlite3.Error):
                logging.exception("Could not save JARVIS settings")
                messagebox.showerror(
                    "Settings could not be saved",
                    "JARVIS couldn't write settings to your local profile. Check disk space and folder permissions.",
                    parent=dialog,
                )
            except ValueError as error:
                messagebox.showerror("Settings", str(error), parent=dialog)

        self._button(buttons, "Test connection", test_connection, primary=True).pack(side="left")
        self._button(buttons, "Clear API key", lambda: self._clear_key(dialog)).pack(side="left", padx=7)
        self._button(buttons, "Clear settings & data", lambda: self._delete_data(dialog)).pack(side="left")
        self._button(buttons, "Save settings", save_settings, primary=True).pack(side="right")
        self.events.put(("settings_bind", dialog))
        dialog.wait_window()

    def _setting_label(self, parent: tk.Widget, text: str) -> None:
        tk.Label(parent, text=text, bg=PANEL, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w", padx=18, pady=(2, 4))

    def _show_help(self) -> None:
        dialog = tk.Toplevel(self.root)
        dialog.title("JARVIS Help")
        dialog.configure(bg=BG)
        dialog.geometry("620x520")
        dialog.minsize(500, 400)
        dialog.transient(self.root)
        tk.Label(
            dialog,
            text="JARVIS QUICK HELP",
            bg=BG,
            fg=CYAN,
            font=("Segoe UI", 16, "bold"),
        ).pack(anchor="w", padx=22, pady=(20, 10))
        help_text = tk.Text(
            dialog, wrap="word", bg=PANEL, fg=TEXT, relief="flat",
            padx=16, pady=14, font=("Segoe UI", 10), state="normal",
        )
        help_text.pack(fill="both", expand=True, padx=22, pady=(0, 14))
        help_text.insert(
            "1.0",
            "Getting started\n"
            "Open Settings, choose a provider, enter its API base URL, model, and API key, "
            "then select Test connection. Save after configuring. API requests need internet "
            "and may use provider credits.\n\n"
            "Chat and voice\n"
            "Type a message and press Enter or Send. Speak activates the microphone only "
            "when clicked; speech recognition sends audio to Google's online service. "
            "Choose Hindi or English/Hinglish and adjust the listening timeout in Settings. "
            "Stop speaking interrupts text-to-speech.\n\n"
            "Local actions\n"
            "Try “open Notepad”, “open Calculator”, “open example.com”, “search the web "
            "for …”, “create note: …”, “show system and network status”, “search files”, "
            "or “open a file”. File/folder selection uses a native picker. JARVIS does not "
            "run terminal commands or destructive actions.\n\n"
            "Privacy and data\n"
            "API keys use Windows Credential Manager. Conversation history is off unless "
            "enabled in Settings. Clear chat removes saved conversation history; Delete "
            "stored data removes local settings, history, notes, and the saved credential.\n\n"
            "Troubleshooting\n"
            "If AI fails, verify the model, provider URL, key, API billing, and internet. "
            "If the microphone or speech engine is unavailable, check Windows privacy and "
            "sound settings; text chat remains usable.\n\n"
            "Design reference\nThe supplied JARVIS image is optional inspiration only; "
            "the working controls are drawn by the app.",
        )
        help_text.configure(state="disabled")
        self._button(
            dialog, "View design reference", self._show_reference_image, compact=True
        ).pack(anchor="w", padx=22, pady=(0, 8))
        self._button(dialog, "Close", dialog.destroy, primary=True).pack(anchor="e", padx=22, pady=(0, 18))
        dialog.focus_set()

    def _show_about(self) -> None:
        dialog = tk.Toplevel(self.root)
        dialog.title("About JARVIS")
        dialog.configure(bg=BG)
        dialog.resizable(False, False)
        dialog.transient(self.root)
        dialog.geometry("420x280")
        tk.Label(dialog, text="◈", fg=CYAN, bg=BG, font=("Segoe UI", 42, "bold")).pack(pady=(18, 0))
        tk.Label(dialog, text="J.A.R.V.I.S. AI", fg=TEXT, bg=BG, font=("Segoe UI", 19, "bold")).pack()
        tk.Label(dialog, text="Version 1.0.0 · Windows desktop assistant", fg=MUTED, bg=BG, font=("Segoe UI", 9)).pack(pady=(4, 12))
        tk.Label(
            dialog,
            text="Cloud AI is optional and configured by the user. Local actions are allow-listed; "
            "microphone access is user-activated.",
            fg=TEXT,
            bg=BG,
            wraplength=350,
            justify="center",
            font=("Segoe UI", 9),
        ).pack(padx=24, pady=4)
        self._button(dialog, "Close", dialog.destroy, primary=True).pack(pady=18)
        dialog.focus_set()

    def _clear_key(self, parent: tk.Toplevel) -> None:
        if not messagebox.askyesno("Clear API key", "Remove the saved API key from Windows Credential Manager?", parent=parent):
            return
        if keyring is None:
            messagebox.showerror("Credential Manager unavailable", "Install dependencies with setup.bat to manage saved API keys.", parent=parent)
            return
        try:
            keyring.delete_password(KEYRING_SERVICE, KEYRING_USERNAME)
        except keyring.errors.PasswordDeleteError:
            pass
        except keyring.errors.KeyringError:
            messagebox.showerror("Credential Manager unavailable", "Windows Credential Manager could not remove the saved API key.", parent=parent)
            return
        self.ai_status.configure(text="● AI not configured", fg=MUTED)
        self.dashboard_api.configure(text="Not configured")
        self.header_status.configure(text="● API NOT CONFIGURED", fg=MUTED)
        messagebox.showinfo("API key", "Saved API key cleared. An OPENAI_API_KEY environment variable, if set, remains available.", parent=parent)

    def _delete_data(self, parent: tk.Toplevel) -> None:
        if not messagebox.askyesno(
            "Delete stored data",
            "Delete saved settings, local conversation history, and the saved API key? This cannot be undone.",
            parent=parent,
        ):
            return
        try:
            self.storage.delete_all()
        except sqlite3.Error:
            logging.exception("Could not delete local JARVIS data")
            messagebox.showerror(
                "Stored data could not be deleted",
                "JARVIS couldn't remove local settings or conversation history. Check folder permissions and try again.",
                parent=parent,
            )
            return
        self.settings = {}
        self.messages.clear()
        self.voice_input.language = "en-IN"
        self.voice_input.timeout = 8
        notes_dir = APP_DIR / "notes"
        if notes_dir.exists():
            try:
                shutil.rmtree(notes_dir)
            except OSError:
                messagebox.showerror(
                    "Could not delete all stored data",
                    f"Settings and conversation history were deleted, but local notes could not be removed from:\n{notes_dir}",
                    parent=parent,
                )
        if keyring is not None:
            try:
                keyring.delete_password(KEYRING_SERVICE, KEYRING_USERNAME)
            except keyring.errors.PasswordDeleteError:
                pass
            except keyring.errors.KeyringError:
                messagebox.showerror(
                    "Credential Manager unavailable",
                    "Local data was deleted, but Windows Credential Manager could not remove the API key.",
                    parent=parent,
                )
        self.chat.configure(state="normal")
        self.chat.delete("1.0", "end")
        self.chat.configure(state="disabled")
        self._append_message("JARVIS", "Local settings and conversation data were deleted.", "assistant", persist=False)
        self.ai_status.configure(text="● AI not configured", fg=MUTED)
        parent.destroy()

    def _clear_chat(self) -> None:
        if not messagebox.askyesno("Clear chat", "Clear the conversation and delete its saved local history?"):
            return
        try:
            self.storage.clear_messages()
        except sqlite3.Error:
            logging.exception("Could not clear conversation history")
            messagebox.showerror(
                "Chat could not be cleared",
                "JARVIS couldn't remove saved conversation history. Check local folder permissions and try again.",
                parent=self.root,
            )
            return
        self.messages.clear()
        self.chat.configure(state="normal")
        self.chat.delete("1.0", "end")
        self.chat.configure(state="disabled")
        self._append_message("JARVIS", "Conversation cleared. What would you like to do?", "assistant", persist=False)

    def _close(self) -> None:
        self.voice_output.stop()
        self.root.destroy()


def main() -> None:
    global _INSTANCE_MUTEX
    try:
        ensure_app_dir()
    except OSError:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(
            "JARVIS could not start",
            "JARVIS cannot create its local data folder. Check your Windows profile permissions and available disk space.",
        )
        root.destroy()
        return
    if os.name == "nt":
        import ctypes

        kernel = ctypes.windll.kernel32
        kernel.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_bool, ctypes.c_wchar_p]
        kernel.CreateMutexW.restype = ctypes.c_void_p
        _INSTANCE_MUTEX = kernel.CreateMutexW(None, False, "Local\\JARVIS_Desktop_Assistant")
        if kernel.GetLastError() == 183:
            root = tk.Tk()
            root.withdraw()
            messagebox.showinfo("JARVIS is already running", "Switch to the existing JARVIS window.")
            root.destroy()
            return
    root = tk.Tk()
    try:
        JarvisApp(root)
        root.mainloop()
    except Exception:
        logging.exception("Application startup failure")
        messagebox.showerror(
            "JARVIS could not start",
            f"An unexpected startup error occurred. Diagnostic details are in:\n{LOG_PATH}",
        )
        raise


if __name__ == "__main__":
    main()
