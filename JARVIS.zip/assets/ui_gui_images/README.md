# JARVIS UI reference images

This folder is reserved for design references, approved mockups, screenshots,
and GUI illustration assets. The supplied JARVIS interface reference is saved
as `reference_ui.png`. Subfolders organize backgrounds, logos, avatars, panels,
and illustrations.

To replace or add a reference, copy a PNG or GIF into this folder and use a
descriptive filename. Reference images guide the interface design; they are
not used as a substitute for functional application widgets. The app handles
missing reference images gracefully.

Do not store API credentials, application databases, notes, or private user
data in this assets directory.
