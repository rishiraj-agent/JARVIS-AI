@echo off
setlocal
cd /d "%~dp0"
set "BUILD_RELEASE="
if exist "dist\current_build.txt" set /p BUILD_RELEASE=<"dist\current_build.txt"
if defined BUILD_RELEASE if exist "dist\%BUILD_RELEASE%\JARVIS-AI\JARVIS-AI.exe" (
    start "" "dist\%BUILD_RELEASE%\JARVIS-AI\JARVIS-AI.exe"
    exit /b 0
)
if exist "dist\release\JARVIS-AI\JARVIS-AI.exe" (
    start "" "dist\release\JARVIS-AI\JARVIS-AI.exe"
    exit /b 0
)
if exist ".venv\Scripts\pythonw.exe" (
    start "" ".venv\Scripts\pythonw.exe" "main.py"
    exit /b 0
)
echo JARVIS is not installed yet. Run setup_dev.bat or setup.bat first.
pause
exit /b 1
