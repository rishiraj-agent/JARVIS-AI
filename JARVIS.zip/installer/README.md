# Installer packaging

The project currently provides a portable PyInstaller onedir application and
an optional one-file executable. No third-party installer project is included.
To create an installer, package `dist\JARVIS-AI\` with a Windows installer
builder such as Inno Setup after reviewing its license and signing workflow.
Do not bundle API credentials or `%LOCALAPPDATA%\JARVIS` user data.
