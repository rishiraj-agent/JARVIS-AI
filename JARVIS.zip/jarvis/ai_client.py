from __future__ import annotations

import json
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any


class AIError(Exception):
    """A safe, user-facing AI service error."""


@dataclass(frozen=True)
class AISettings:
    api_key: str
    base_url: str
    model: str
    temperature: float
    system_prompt: str


class AIClient:
    def __init__(self, settings: AISettings, timeout: int = 30) -> None:
        self.settings = settings
        self.timeout = timeout

    def _request(self, method: str, endpoint: str, payload: dict[str, Any] | None = None) -> Any:
        key = self.settings.api_key.strip()
        if not key:
            raise AIError(
                "No API key is configured. Add one in Settings or set the "
                "OPENAI_API_KEY environment variable."
            )
        base = self.settings.base_url.strip().rstrip("/")
        if not base.startswith(("https://", "http://")):
            raise AIError("The API base URL must begin with https:// or http://.")
        if base.startswith("http://") and not _is_loopback(base):
            raise AIError("For security, non-local API endpoints must use HTTPS.")
        request = urllib.request.Request(
            f"{base}/{endpoint.lstrip('/')}",
            data=json.dumps(payload).encode("utf-8") if payload is not None else None,
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
                "User-Agent": "JARVIS-Desktop/1.0",
            },
            method=method,
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                body = response.read(2_000_000)
        except urllib.error.HTTPError as error:
            status = error.code
            try:
                detail_data = json.loads(error.read(32_000).decode("utf-8", errors="replace"))
                detail = detail_data.get("error", {}).get("message", "")
            except (json.JSONDecodeError, AttributeError, TypeError):
                detail = ""
            detail = str(detail).replace(key, "[redacted]")[:240]
            if status in (401, 403):
                message = "The API key was rejected. Check the key and provider account."
            elif status == 402:
                message = "The provider reports a billing or credit problem. Check API billing."
            elif status == 404:
                message = "The endpoint or model was not found. Check the base URL and model name."
            elif status == 429:
                message = "The provider rate-limited this request or the account has no remaining quota."
            elif status >= 500:
                message = "The AI provider is temporarily unavailable. Try again shortly."
            else:
                message = f"The AI provider returned HTTP {status}."
            if detail:
                message += f" Provider detail: {detail}"
            raise AIError(message) from None
        except (urllib.error.URLError, TimeoutError, OSError) as error:
            if isinstance(error, TimeoutError) or "timed out" in str(error).lower():
                raise AIError("The request timed out. Check your connection and try again.") from None
            if isinstance(error, urllib.error.URLError) and isinstance(error.reason, TimeoutError):
                raise AIError("The request timed out. Check your connection and try again.") from None
            raise AIError("Could not reach the AI provider. Check your internet connection and URL.") from None
        try:
            return json.loads(body.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            raise AIError("The AI provider returned an unreadable response.") from None

    def chat(self, messages: list[dict[str, str]]) -> str:
        response = self._request(
            "POST",
            "chat/completions",
            {
                "model": self.settings.model,
                "temperature": self.settings.temperature,
                "messages": [
                    {"role": "system", "content": self.settings.system_prompt},
                    *messages[-40:],
                ],
            },
        )
        try:
            content = response["choices"][0]["message"]["content"]
            if isinstance(content, str) and content.strip():
                return content.strip()
        except (KeyError, IndexError, TypeError):
            pass
        raise AIError("The provider response did not contain a text answer.")

    def chat_stream(self, messages: list[dict[str, str]]):
        key = self.settings.api_key.strip()
        if not key:
            raise AIError(
                "No API key is configured. Add one in Settings or set the "
                "OPENAI_API_KEY environment variable."
            )
        base = self.settings.base_url.strip().rstrip("/")
        if not base.startswith(("https://", "http://")):
            raise AIError("The API base URL must begin with https:// or http://.")
        if base.startswith("http://") and not _is_loopback(base):
            raise AIError("For security, non-local API endpoints must use HTTPS.")
        request = urllib.request.Request(
            f"{base}/chat/completions",
            data=json.dumps(
                {
                    "model": self.settings.model,
                    "temperature": self.settings.temperature,
                    "stream": True,
                    "messages": [
                        {"role": "system", "content": self.settings.system_prompt},
                        *messages[-40:],
                    ],
                }
            ).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
                "Accept": "text/event-stream",
                "User-Agent": "JARVIS-Desktop/1.0",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                received = False
                for raw_line in response:
                    line = raw_line.decode("utf-8", errors="replace").strip()
                    if not line.startswith("data:"):
                        continue
                    payload = line[5:].strip()
                    if payload == "[DONE]":
                        break
                    try:
                        event = json.loads(payload)
                    except json.JSONDecodeError:
                        continue
                    if isinstance(event, dict) and event.get("error"):
                        raise AIError("The AI provider returned an error during streaming.")
                    try:
                        delta = event["choices"][0]["delta"].get("content")
                    except (KeyError, IndexError, TypeError, AttributeError):
                        continue
                    if isinstance(delta, str) and delta:
                        received = True
                        yield delta
                if not received:
                    raise AIError("The provider completed the stream without returning text.")
        except urllib.error.HTTPError as error:
            message = _http_error_message(error, key)
            raise AIError(message) from None
        except (urllib.error.URLError, TimeoutError, OSError) as error:
            if isinstance(error, TimeoutError) or "timed out" in str(error).lower():
                raise AIError("The request timed out. Check your connection and try again.") from None
            if isinstance(error, urllib.error.URLError) and isinstance(error.reason, TimeoutError):
                raise AIError("The request timed out. Check your connection and try again.") from None
            raise AIError("Could not reach the AI provider. Check your internet connection and URL.") from None

    def test_connection(self) -> str:
        response = self._request(
            "POST",
            "chat/completions",
            {
                "model": self.settings.model,
                "temperature": 0,
                "max_tokens": 8,
                "messages": [{"role": "user", "content": "Reply with OK."}],
            },
        )
        try:
            if response["choices"][0]["message"]["content"]:
                return f"Connected successfully; model '{self.settings.model}' answered."
        except (KeyError, IndexError, TypeError):
            pass
        raise AIError("The connection test returned no answer.")


def _is_loopback(url: str) -> bool:
    from urllib.parse import urlparse

    hostname = (urlparse(url).hostname or "").lower()
    return hostname == "localhost" or hostname == "127.0.0.1" or hostname == "::1"
