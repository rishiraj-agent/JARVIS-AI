from __future__ import annotations

import queue
import threading
import time


class VoiceInput:
    def __init__(self, timeout: int = 8, phrase_limit: int = 15, language: str = "en-IN") -> None:
        self.timeout = timeout
        self.phrase_limit = phrase_limit
        self.language = language

    def listen(self, cancelled: threading.Event | None = None) -> str:
        cancelled = cancelled or threading.Event()
        try:
            import speech_recognition as sr
        except ImportError as error:
            raise RuntimeError(
                "Speech recognition is not installed. Text chat still works; "
                "run setup.bat to install voice dependencies."
            ) from error
        try:
            recognizer = sr.Recognizer()
            with sr.Microphone() as microphone:
                recognizer.adjust_for_ambient_noise(microphone, duration=0.4)
                audio_queue: queue.Queue[object] = queue.Queue(maxsize=1)

                def capture(_recognizer, audio) -> None:
                    try:
                        audio_queue.put_nowait(audio)
                    except queue.Full:
                        pass

                stop_listener = recognizer.listen_in_background(
                    microphone,
                    capture,
                    phrase_time_limit=self.phrase_limit,
                )
                deadline = time.monotonic() + self.timeout
                audio = None
                try:
                    while not cancelled.is_set() and time.monotonic() < deadline:
                        try:
                            audio = audio_queue.get(timeout=0.1)
                            break
                        except queue.Empty:
                            continue
                finally:
                    stop_listener(wait_for_stop=True)
                if cancelled.is_set():
                    raise RuntimeError("Listening stopped.")
                if audio is None:
                    raise RuntimeError("No speech was detected before the listening timeout.")
            try:
                if cancelled.is_set():
                    raise RuntimeError("Listening stopped.")
                return recognizer.recognize_google(audio, language=self.language)
            except sr.UnknownValueError:
                raise RuntimeError("I couldn't understand that. Please try again.") from None
            except sr.RequestError:
                raise RuntimeError(
                    "Speech recognition could not reach Google's speech service. "
                    "Check your internet connection."
                ) from None
        except sr.WaitTimeoutError:
            raise RuntimeError("No speech was detected before the listening timeout.") from None
        except OSError as error:
            raise RuntimeError(
                "A microphone could not be opened. Check Windows microphone permissions "
                "and that an input device is connected."
            ) from error
