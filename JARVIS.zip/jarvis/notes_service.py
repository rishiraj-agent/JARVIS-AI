from __future__ import annotations

from jarvis.storage import Storage


class NotesService:
    def __init__(self, storage: Storage) -> None:
        self.storage = storage

    def search(self, query: str = "") -> list[dict[str, object]]:
        return self.storage.get_notes(query)

    def save(self, title: str, body: str, note_id: int | None = None) -> int:
        normalized_title = title.strip()
        normalized_body = body.strip()
        if not normalized_title:
            raise ValueError("A note title is required.")
        if not normalized_body:
            raise ValueError("Note content cannot be empty.")
        if len(normalized_title) > 160:
            raise ValueError("Note title must be 160 characters or fewer.")
        return self.storage.save_note(normalized_title, normalized_body, note_id)

    def delete(self, note_id: int) -> None:
        self.storage.delete_note(note_id)


class ReminderService:
    def __init__(self, storage: Storage) -> None:
        self.storage = storage

    def create(
        self, title: str, due_at: str, details: str = "", reminder_id: int | None = None
    ) -> int:
        normalized_title = title.strip()
        if not normalized_title:
            raise ValueError("A reminder title is required.")
        if len(normalized_title) > 160:
            raise ValueError("Reminder title must be 160 characters or fewer.")
        normalized_details = details.strip()
        if len(normalized_details) > 2000:
            raise ValueError("Reminder details must be 2000 characters or fewer.")
        from datetime import datetime

        try:
            parsed = datetime.fromisoformat(due_at)
        except ValueError:
            raise ValueError("Enter a valid date and time.") from None
        if parsed.tzinfo is None:
            parsed = parsed.astimezone()
        return self.storage.save_reminder(
            normalized_title, parsed.isoformat(timespec="minutes"),
            normalized_details, reminder_id,
        )

    def upcoming(self) -> list[dict[str, object]]:
        return self.storage.get_reminders(include_completed=False)

    def complete(self, reminder_id: int, completed: bool = True) -> None:
        self.storage.set_reminder_completed(reminder_id, completed)

    def delete(self, reminder_id: int) -> None:
        self.storage.delete_reminder(reminder_id)
