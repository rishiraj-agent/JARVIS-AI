# JARVIS AI — Windows desktop assistant

JARVIS AI is a native Tkinter desktop app for Windows 10/11. It combines an optional OpenAI-compatible Chat Completions API, opt-in speech recognition, offline text-to-speech, a local notes/reminders database, system monitoring, configurable app shortcuts, and an explicit allow-list of built-in desktop actions. The app does not require Ollama, Docker, Node.js, a local model, or a backend exposed to the network.

## Architecture

- `main.py`: Tkinter interface, settings, worker-thread coordination, and event handlers.
- `jarvis/ai_client.py`: HTTPS OpenAI-compatible API requests using Python's standard library.
- `jarvis/automation.py`: local date/time, allow-listed apps, browser navigation/search, notes, file-name listing, CPU/RAM/system/network status, and supported Windows output-volume control. It never runs shell commands from AI output.
- `jarvis/voice_input.py` / `jarvis/voice_output.py`: explicitly activated microphone input and offline TTS.
- `jarvis/storage.py`: SQLite settings and optional local message history.
- `jarvis/notes_service.py`: validated persistent note and reminder operations.
- `jarvis/system_monitor.py`: real CPU, memory, disk, OS, processor, and battery values (unavailable metrics are reported as unavailable).
- `jarvis/image_loader.py`: optional PNG/GIF loader; the supplied design reference lives in `assets\ui_gui_images\reference_ui.png` and is shown only in the Help preview.
- API keys are stored in Windows Credential Manager through `keyring`; `OPENAI_API_KEY` is a supported per-user environment-variable fallback.

## UI reference assets

The supplied interface image is included at `assets\ui_gui_images\reference_ui.png`.
Use **Help → View design reference** to preview it. It is an optional design
reference only; missing or unreadable images do not affect the native GUI.
Place additional PNG/GIF design references in `assets\ui_gui_images\` and see
that folder's README for organization. Private credentials and user data belong
in the application-data folder, never in assets.

## Requirements and installation

1. Install **64-bit Python 3.11** from [python.org](https://www.python.org/downloads/windows/). During installation enable **Add python.exe to PATH** and the **Python Launcher**.
2. Double-click `setup_dev.bat` (or `setup.bat`) once. It creates a project-local `.venv` and installs the dependencies.
3. Double-click `start_jarvis.bat` to launch JARVIS from source, or use `run.bat` to prefer the built portable EXE when it exists. Run setup again if dependencies need updating.

Equivalent commands in PowerShell, from the project directory:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe main.py
```

The app and conversation data are stored under `%LOCALAPPDATA%\JARVIS`; API keys are not written into the SQLite database. Do not put keys in source files or commit them.

## Build the Windows executables

On Windows with 64-bit Python 3.11 installed, double-click `build_exe.bat`. It creates/uses `.venv`, installs the requirements, validates imports and Python syntax, runs tests, and packages the full `assets` directory (including the optional reference image). It then builds:

- Portable folder app: `dist\release-<build-id>\JARVIS-AI\JARVIS-AI.exe` (preferred; keep the adjacent files together).
- Optional single-file app: `dist\release-<build-id>\JARVIS-AI.exe` (self-extracts at launch; settings and user data remain under `%LOCALAPPDATA%\JARVIS`, not in the temporary extraction directory).

Each build gets a fresh release folder to avoid collisions with synchronized or locked prior outputs; `dist\current_build.txt` identifies the latest successful folder, and `run.bat` launches its onedir executable.

The script uses the included `assets\jarvis.ico` if present and otherwise continues with PyInstaller's default icon. PyInstaller output is Windows-specific; build on Windows for a Windows executable. SmartScreen/reputation warnings may appear for unsigned builds. Do not distribute API keys with the executable.

Use `build_exe_onedir.bat` for the preferred portable build or `build_exe_onefile.bat` for only the optional single-file executable. The combined `build_exe.bat` builds both.

To build only the portable onedir version manually after running setup:

```powershell
.\.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --windowed --onedir --name JARVIS-AI --distpath dist --icon assets\jarvis.ico --add-data "assets;assets" main.py
```

`build_exe.bat` runs the included unit tests before packaging. The `.env.example` is only a key-free example; production credentials belong in Credential Manager or a Windows user environment variable.

## Configure an AI provider

1. Select **Settings** in JARVIS.
2. Select **OpenAI**, **OpenRouter**, or **Custom OpenAI-compatible**. Enter the provider's Chat Completions API base URL (OpenAI and OpenRouter have defaults), a model name available to your API account, and your API key.
3. Press **Test connection**. It sends a short Chat Completions request, so the provider may charge a small amount. A success is shown only after a response is received.
4. Press **Save settings**. The key is saved to Windows Credential Manager; settings other than the key are stored locally in SQLite.

The default is `https://api.openai.com/v1` and `gpt-4o-mini`. Model availability and billing depend on the provider and API account. A ChatGPT subscription does **not** necessarily include API credits. If you prefer environment-based configuration, set `OPENAI_API_KEY` for your Windows user and restart JARVIS. API requests require internet access.

The connection test checks the configured key, URL, and model by making a real completion request. Chat Completions providers may differ in supported parameters or model names.

## Voice, privacy, and history

- Click **Speak** to activate the microphone; JARVIS never continuously records. Speech recognition currently uses Google's online recognition service and transmits audio only after activation. It requires internet access.
- Choose `en-IN` for English/Hinglish or `hi-IN` for Hindi, and set a 3–60 second listening timeout in Settings. Stop listening with the microphone button; **Stop speaking** interrupts text-to-speech.
- Speech output uses `pyttsx3` and Windows speech voices offline where available. Text-only use remains available if either voice feature is unavailable.
- Windows may require microphone permission under **Settings → Privacy & security → Microphone**. Confirm that a recording device is enabled in Windows sound settings.
- Conversation history is off by default. Enable **Save conversation history on this PC** in Settings to persist local messages. **Clear chat** deletes saved message history; **Clear settings & data** removes saved settings, history, locally created notes, and the Credential Manager key (after confirmation).
- Notes and reminders persist in SQLite under `%LOCALAPPDATA%\JARVIS`. Notes can be searched, edited, and deleted. Reminders are stored and shown in the dashboard, but are not scheduled as Windows notifications; keep JARVIS open and check the reminder panel.
- The Applications page supports the built-in allow-list and user-added `.exe` shortcuts. A shortcut is launched with `shell=False` only after the user explicitly selects its executable.
- The system dashboard refreshes real OS, CPU, memory, disk, and battery metrics in a background worker; battery information may be unavailable on desktops.
- Diagnostics are written to `%LOCALAPPDATA%\JARVIS\jarvis.log`; logs do not intentionally include API keys, prompts, or conversation content.

## Supported local commands

Try phrases such as:

- “What time is it?” / “What is today's date?”
- “Open Calculator”, “Open Notepad”, or “Open Paint”
- “Open example.com”
- “Search the web for Windows 11 tips”
- “Search files” — JARVIS asks you to choose a folder and lists up to 500 file names. It does not open or modify files.
- “Open a file” / “Open a folder” — choose the item in a Windows file picker before JARVIS opens it.
- “Show system and network status”
- “Set volume to 30%”
- “Create note: call the dentist tomorrow”
- The Notes page can also create, edit, search, and delete notes, and save reminders in `YYYY-MM-DD HH:MM` format.
- The Applications page lets you select and save user-approved executable shortcuts; double-click a shortcut to launch it.

Actions are handled locally only when they match supported commands. Other requests go to the configured AI and display streamed response chunks as they arrive. Web search opens Google in your default browser; JARVIS does not claim that browser results are verified or show scraped citations. Unimplemented or sensitive operations are not executed.

## Test the app

With the development environment installed, run:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

In the app, visit each sidebar page, save/edit/delete a note, create/edit/complete a reminder, add and open an application shortcut, run a browser search, and check the live system page. Test AI by configuring your own API key and selecting **Test connection**. Voice tests require a microphone and an internet connection for speech recognition; speech synthesis uses installed Windows voices. Home includes recent locally saved activity. Reminders remain app-visible only and do not trigger Windows notifications.

## Feature status and verification

- **Implemented:** Tkinter desktop UI and navigation; real OpenAI-compatible API calls and connection testing; credential storage; streamed chat; user-activated voice input and offline TTS; persistent notes, reminders, settings, and optional chat history; system metrics; browser search; allow-listed local commands; user-approved executable shortcuts; PyInstaller onedir and one-file builds.
- **Optional:** A configured API key/provider, microphone and PyAudio support, Google speech-recognition connectivity, installed Windows speech voices, and user-added application shortcuts. Text chat and local tools remain available without these services.
- **Not implemented:** Windows toast notifications for reminders, arbitrary AI-generated command execution, and a live-web retrieval/search API. Search opens a browser query and does not provide verified result summaries.
- **Not hardware/account verified:** The local test suite and GUI/package smoke tests do not verify a user's external AI billing/key, microphone hardware, or audible device playback. Test those on the target Windows PC before relying on them.

## Troubleshooting

- **Python 3.11 not found:** install 64-bit Python 3.11 and its launcher, then reopen the terminal and run `setup.bat`.
- **PyAudio installation fails:** use 64-bit Python 3.11, update pip with the command above, and rerun setup. Text chat remains usable without the microphone package.
- **No microphone:** check Windows microphone privacy permissions, input-device selection, and whether another application is using the device.
- **No speech output:** select/install a Windows speech voice; JARVIS still displays text responses.
- **401/403:** check the API key and provider endpoint. **402/429:** inspect API billing, credits, and rate limits. **404:** verify the model name and base URL. ChatGPT web access alone does not establish API access.
- **Network errors:** AI requests and Google speech recognition need internet access. Local commands, note creation, SQLite, and installed Windows TTS can work offline.
- **App does not open:** run `.venv\Scripts\python.exe main.py` from PowerShell to see startup diagnostics. The log is at `%LOCALAPPDATA%\JARVIS\jarvis.log`.
- **Credential Manager unavailable:** set `OPENAI_API_KEY` in the Windows user's environment variables and relaunch; do not put the key in a script.
- **Build fails at PyAudio:** use 64-bit Python 3.11 and upgrade pip; PyAudio needs a compatible Windows wheel. Text chat can run without microphone support, but the current packaged build expects the declared requirements to install.
- **Executable is quarantined or warned about:** unsigned, locally built executables can trigger SmartScreen or antivirus heuristics. Verify the build source and do not bypass warnings for binaries from untrusted sources.

JARVIS is a user-launched desktop program. It does not install a service, expose an HTTP server, monitor in the background, or execute model-generated terminal commands.
