from __future__ import annotations

import tempfile
import json
import sqlite3
import threading
import unittest
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from jarvis.ai_client import AIClient, AIError, AISettings
from jarvis.notes_service import NotesService, ReminderService
from jarvis.storage import Storage
from jarvis.system_monitor import collect_system_snapshot
from jarvis.image_loader import ImageLoader
from jarvis.automation import run_command


class StorageAndServiceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.storage = Storage(Path(self.temp.name) / "jarvis.sqlite3")
        self.notes = NotesService(self.storage)
        self.reminders = ReminderService(self.storage)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def test_notes_create_search_update_delete(self) -> None:
        note_id = self.notes.save("Project", "Remember the cyan theme")
        self.assertEqual(self.notes.search("cyan")[0]["id"], note_id)
        self.notes.save("Project updated", "Done", note_id)
        self.assertEqual(self.notes.search()[0]["title"], "Project updated")
        self.notes.delete(note_id)
        self.assertEqual(self.notes.search(), [])

    def test_reminder_validation_and_completion(self) -> None:
        with self.assertRaises(ValueError):
            self.reminders.create("", "2030-01-01 10:00")
        with self.assertRaises(ValueError):
            self.reminders.create("Review", "not-a-date")
        reminder_id = self.reminders.create("Review", "2030-01-01 10:00", "Check the outline")
        self.assertEqual(len(self.reminders.upcoming()), 1)
        self.assertEqual(self.reminders.upcoming()[0]["details"], "Check the outline")
        self.reminders.create("Review updated", "2030-01-02 10:00", "Updated", reminder_id)
        self.assertEqual(self.reminders.upcoming()[0]["title"], "Review updated")
        self.reminders.complete(reminder_id)
        self.assertEqual(self.reminders.upcoming(), [])

    def test_settings_and_search_history_persist(self) -> None:
        self.storage.save_settings({"model": "sample", "animations": True})
        self.storage.add_search("Windows desktop")
        self.assertEqual(self.storage.get_settings()["model"], "sample")
        self.assertEqual(self.storage.get_searches()[0], "Windows desktop")


class APIValidationTests(unittest.TestCase):
    def test_missing_api_key_is_actionable(self) -> None:
        client = AIClient(AISettings("", "https://api.openai.com/v1", "model", 0.4, "system"))
        with self.assertRaisesRegex(AIError, "No API key"):
            client.chat([])

    def test_plain_http_public_api_is_rejected(self) -> None:
        client = AIClient(AISettings("secret", "http://example.com/v1", "model", 0.4, "system"))
        with self.assertRaisesRegex(AIError, "HTTPS"):
            client.chat([])

    def test_chat_stream_yields_provider_chunks(self) -> None:
        received: list[dict[str, object]] = []

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self) -> None:
                body = self.rfile.read(int(self.headers["Content-Length"]))
                received.append(
                    {
                        "authorization": self.headers.get("Authorization"),
                        "payload": json.loads(body),
                    }
                )
                events = (
                    b'data: {"choices":[{"delta":{"content":"Hello "}}]}\n\n'
                    b'data: {"choices":[{"delta":{"content":"world"}}]}\n\n'
                    b"data: [DONE]\n\n"
                )
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Content-Length", str(len(events)))
                self.end_headers()
                self.wfile.write(events)

            def log_message(self, _format: str, *_args: object) -> None:
                pass

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            client = AIClient(
                AISettings(
                    "test-key",
                    f"http://127.0.0.1:{server.server_port}/v1",
                    "test-model",
                    0.3,
                    "system",
                )
            )
            self.assertEqual(
                list(client.chat_stream([{"role": "user", "content": "hi"}])),
                ["Hello ", "world"],
            )
            self.assertEqual(received[0]["authorization"], "Bearer test-key")
            self.assertTrue(received[0]["payload"]["stream"])
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)


class SystemMonitorTests(unittest.TestCase):
    def test_system_snapshot_has_real_platform_and_optional_metrics(self) -> None:
        snapshot = collect_system_snapshot()
        self.assertTrue(snapshot.operating_system)
        self.assertTrue(snapshot.processor)
        if snapshot.cpu_percent is not None:
            self.assertGreaterEqual(snapshot.cpu_percent, 0)
            self.assertLessEqual(snapshot.cpu_percent, 100)


class ReliabilityTests(unittest.TestCase):
    def test_missing_reference_image_is_optional(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            missing = Path(directory) / "missing.png"
            self.assertIsNone(ImageLoader().load(missing))

    def test_unknown_commands_are_not_executed(self) -> None:
        self.assertIsNone(run_command("run powershell.exe -Command whoami"))

    def test_app_imports_without_starting_gui(self) -> None:
        import main

        self.assertTrue(callable(main.main))
        self.assertTrue(hasattr(main, "JarvisApp"))

    def test_existing_reminder_database_migrates_details_column(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "old.sqlite3"
            connection = sqlite3.connect(path)
            try:
                connection.execute(
                    "CREATE TABLE reminders (id INTEGER PRIMARY KEY, title TEXT NOT NULL, "
                    "due_at TEXT NOT NULL, completed INTEGER NOT NULL DEFAULT 0, "
                    "created_at TEXT NOT NULL)"
                )
                connection.execute(
                    "INSERT INTO reminders(title, due_at, created_at) "
                    "VALUES('Existing', '2030-01-01 10:00', '2030-01-01')"
                )
                connection.commit()
            finally:
                connection.close()
            migrated = Storage(path)
            self.assertEqual(migrated.get_reminders()[0]["details"], "")

    def test_reference_image_is_part_of_project_assets(self) -> None:
        from config import REFERENCE_IMAGE_PATH

        self.assertTrue(REFERENCE_IMAGE_PATH.is_file())


if __name__ == "__main__":
    unittest.main()
